The following files were generated for 'signed_divider' in directory
E:\N.I.G.E.-Machine\Xilinx_ISE\ipcore_dir\

XCO file generator:
   Generate an XCO file for compatibility with legacy flows.

   * signed_divider.xco

Creates an implementation netlist:
   Creates an implementation netlist for the IP.

   * signed_divider.ngc
   * signed_divider.v
   * signed_divider.veo
   * signed_divider.vhd
   * signed_divider.vho

Creates an HDL instantiation template:
   Creates an HDL instantiation template for the IP.

   * signed_divider.veo
   * signed_divider.vho

IP Symbol Generator:
   Generate an IP symbol based on the current project options'.

   * signed_divider.asy

Generate ISE metadata:
   Create a metadata file for use when including this core in ISE designs

   * signed_divider_xmdf.tcl

Generate ISE subproject:
   Create an ISE subproject for use when including this core in ISE designs

   * _xmsgs/pn_parser.xmsgs
   * signed_divider.gise
   * signed_divider.xise

Deliver Readme:
   Readme file for the IP.

   * signed_divider_readme.txt

Generate FLIST file:
   Text file listing all of the output files produced when a customized core was
   generated in the CORE Generator.

   * signed_divider_flist.txt

Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

