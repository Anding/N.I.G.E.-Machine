The following files were generated for 'unsigned_divider' in directory
E:\N.I.G.E.-Machine\Xilinx_ISE\ipcore_dir\

XCO file generator:
   Generate an XCO file for compatibility with legacy flows.

   * unsigned_divider.xco

Creates an implementation netlist:
   Creates an implementation netlist for the IP.

   * unsigned_divider.ngc
   * unsigned_divider.v
   * unsigned_divider.veo
   * unsigned_divider.vhd
   * unsigned_divider.vho

Creates an HDL instantiation template:
   Creates an HDL instantiation template for the IP.

   * unsigned_divider.veo
   * unsigned_divider.vho

IP Symbol Generator:
   Generate an IP symbol based on the current project options'.

   * unsigned_divider.asy

Generate ISE metadata:
   Create a metadata file for use when including this core in ISE designs

   * unsigned_divider_xmdf.tcl

Generate ISE subproject:
   Create an ISE subproject for use when including this core in ISE designs

   * _xmsgs/pn_parser.xmsgs
   * unsigned_divider.gise
   * unsigned_divider.xise

Deliver Readme:
   Readme file for the IP.

   * unsigned_divider_readme.txt

Generate FLIST file:
   Text file listing all of the output files produced when a customized core was
   generated in the CORE Generator.

   * unsigned_divider_flist.txt

Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

