/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "E:/N.I.G.E.-Machine/VHDL/Logic.vhd";
extern char *IEEE_P_2592010699;

char *ieee_p_2592010699_sub_1697423399_503743352(char *, char *, char *, char *, char *, char *);
char *ieee_p_2592010699_sub_1735675855_503743352(char *, char *, char *, char *, char *, char *);
char *ieee_p_2592010699_sub_1837678034_503743352(char *, char *, char *, char *);
char *ieee_p_2592010699_sub_795620321_503743352(char *, char *, char *, char *, char *, char *);


static void work_a_1248124681_1516540902_p_0(char *t0)
{
    char t23[16];
    char t39[16];
    char *t1;
    char *t2;
    char *t3;
    int t4;
    char *t5;
    char *t6;
    int t7;
    char *t8;
    char *t9;
    int t10;
    char *t11;
    char *t12;
    int t13;
    char *t14;
    char *t15;
    int t16;
    char *t17;
    int t19;
    char *t20;
    int t22;
    char *t24;
    char *t25;
    char *t26;
    char *t27;
    char *t28;
    char *t29;
    unsigned int t30;
    unsigned int t31;
    unsigned char t32;
    char *t33;
    char *t34;
    char *t35;
    char *t36;
    char *t37;
    unsigned int t38;
    unsigned int t40;
    unsigned int t41;
    unsigned int t42;
    unsigned int t43;
    unsigned char t44;

LAB0:    xsi_set_current_line(30, ng0);
    t1 = (t0 + 1352U);
    t2 = *((char **)t1);
    t1 = (t0 + 4763);
    t4 = xsi_mem_cmp(t1, t2, 3U);
    if (t4 == 1)
        goto LAB3;

LAB11:    t5 = (t0 + 4766);
    t7 = xsi_mem_cmp(t5, t2, 3U);
    if (t7 == 1)
        goto LAB4;

LAB12:    t8 = (t0 + 4769);
    t10 = xsi_mem_cmp(t8, t2, 3U);
    if (t10 == 1)
        goto LAB5;

LAB13:    t11 = (t0 + 4772);
    t13 = xsi_mem_cmp(t11, t2, 3U);
    if (t13 == 1)
        goto LAB6;

LAB14:    t14 = (t0 + 4775);
    t16 = xsi_mem_cmp(t14, t2, 3U);
    if (t16 == 1)
        goto LAB7;

LAB15:    t17 = (t0 + 4778);
    t19 = xsi_mem_cmp(t17, t2, 3U);
    if (t19 == 1)
        goto LAB8;

LAB16:    t20 = (t0 + 4781);
    t22 = xsi_mem_cmp(t20, t2, 3U);
    if (t22 == 1)
        goto LAB9;

LAB17:
LAB10:    xsi_set_current_line(46, ng0);
    t1 = (t0 + 1192U);
    t2 = *((char **)t1);
    t1 = (t0 + 4640U);
    t3 = ieee_p_2592010699_sub_1837678034_503743352(IEEE_P_2592010699, t23, t2, t1);
    t5 = (t23 + 12U);
    t30 = *((unsigned int *)t5);
    t31 = (1U * t30);
    t32 = (32U != t31);
    if (t32 == 1)
        goto LAB33;

LAB34:    t6 = (t0 + 3072);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    t11 = (t9 + 56U);
    t12 = *((char **)t11);
    memcpy(t12, t3, 32U);
    xsi_driver_first_trans_fast_port(t6);

LAB2:    t1 = (t0 + 2992);
    *((int *)t1) = 1;

LAB1:    return;
LAB3:    xsi_set_current_line(32, ng0);
    t24 = (t0 + 1032U);
    t25 = *((char **)t24);
    t24 = (t0 + 4624U);
    t26 = (t0 + 1192U);
    t27 = *((char **)t26);
    t26 = (t0 + 4640U);
    t28 = ieee_p_2592010699_sub_795620321_503743352(IEEE_P_2592010699, t23, t25, t24, t27, t26);
    t29 = (t23 + 12U);
    t30 = *((unsigned int *)t29);
    t31 = (1U * t30);
    t32 = (32U != t31);
    if (t32 == 1)
        goto LAB19;

LAB20:    t33 = (t0 + 3072);
    t34 = (t33 + 56U);
    t35 = *((char **)t34);
    t36 = (t35 + 56U);
    t37 = *((char **)t36);
    memcpy(t37, t28, 32U);
    xsi_driver_first_trans_fast_port(t33);
    goto LAB2;

LAB4:    xsi_set_current_line(34, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 4624U);
    t3 = (t0 + 1192U);
    t5 = *((char **)t3);
    t3 = (t0 + 4640U);
    t6 = ieee_p_2592010699_sub_1735675855_503743352(IEEE_P_2592010699, t23, t2, t1, t5, t3);
    t8 = (t23 + 12U);
    t30 = *((unsigned int *)t8);
    t31 = (1U * t30);
    t32 = (32U != t31);
    if (t32 == 1)
        goto LAB21;

LAB22:    t9 = (t0 + 3072);
    t11 = (t9 + 56U);
    t12 = *((char **)t11);
    t14 = (t12 + 56U);
    t15 = *((char **)t14);
    memcpy(t15, t6, 32U);
    xsi_driver_first_trans_fast_port(t9);
    goto LAB2;

LAB5:    xsi_set_current_line(36, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 4624U);
    t3 = (t0 + 1192U);
    t5 = *((char **)t3);
    t3 = (t0 + 4640U);
    t6 = ieee_p_2592010699_sub_1697423399_503743352(IEEE_P_2592010699, t23, t2, t1, t5, t3);
    t8 = (t23 + 12U);
    t30 = *((unsigned int *)t8);
    t31 = (1U * t30);
    t32 = (32U != t31);
    if (t32 == 1)
        goto LAB23;

LAB24:    t9 = (t0 + 3072);
    t11 = (t9 + 56U);
    t12 = *((char **)t11);
    t14 = (t12 + 56U);
    t15 = *((char **)t14);
    memcpy(t15, t6, 32U);
    xsi_driver_first_trans_fast_port(t9);
    goto LAB2;

LAB6:    xsi_set_current_line(38, ng0);
    t1 = (t0 + 1192U);
    t2 = *((char **)t1);
    t30 = (31 - 30);
    t31 = (t30 * 1U);
    t38 = (0 + t31);
    t1 = (t2 + t38);
    t5 = ((IEEE_P_2592010699) + 4024);
    t6 = (t39 + 0U);
    t8 = (t6 + 0U);
    *((int *)t8) = 30;
    t8 = (t6 + 4U);
    *((int *)t8) = 0;
    t8 = (t6 + 8U);
    *((int *)t8) = -1;
    t4 = (0 - 30);
    t40 = (t4 * -1);
    t40 = (t40 + 1);
    t8 = (t6 + 12U);
    *((unsigned int *)t8) = t40;
    t3 = xsi_base_array_concat(t3, t23, t5, (char)97, t1, t39, (char)99, (unsigned char)2, (char)101);
    t40 = (31U + 1U);
    t32 = (32U != t40);
    if (t32 == 1)
        goto LAB25;

LAB26:    t8 = (t0 + 3072);
    t9 = (t8 + 56U);
    t11 = *((char **)t9);
    t12 = (t11 + 56U);
    t14 = *((char **)t12);
    memcpy(t14, t3, 32U);
    xsi_driver_first_trans_fast_port(t8);
    goto LAB2;

LAB7:    xsi_set_current_line(40, ng0);
    t1 = (t0 + 1192U);
    t2 = *((char **)t1);
    t30 = (31 - 31);
    t31 = (t30 * 1U);
    t38 = (0 + t31);
    t1 = (t2 + t38);
    t5 = ((IEEE_P_2592010699) + 4024);
    t6 = (t39 + 0U);
    t8 = (t6 + 0U);
    *((int *)t8) = 31;
    t8 = (t6 + 4U);
    *((int *)t8) = 1;
    t8 = (t6 + 8U);
    *((int *)t8) = -1;
    t4 = (1 - 31);
    t40 = (t4 * -1);
    t40 = (t40 + 1);
    t8 = (t6 + 12U);
    *((unsigned int *)t8) = t40;
    t3 = xsi_base_array_concat(t3, t23, t5, (char)99, (unsigned char)2, (char)97, t1, t39, (char)101);
    t40 = (1U + 31U);
    t32 = (32U != t40);
    if (t32 == 1)
        goto LAB27;

LAB28:    t8 = (t0 + 3072);
    t9 = (t8 + 56U);
    t11 = *((char **)t9);
    t12 = (t11 + 56U);
    t14 = *((char **)t12);
    memcpy(t14, t3, 32U);
    xsi_driver_first_trans_fast_port(t8);
    goto LAB2;

LAB8:    xsi_set_current_line(42, ng0);
    t1 = (t0 + 1192U);
    t2 = *((char **)t1);
    t30 = (31 - 30);
    t31 = (t30 * 1U);
    t38 = (0 + t31);
    t1 = (t2 + t38);
    t5 = ((IEEE_P_2592010699) + 4024);
    t6 = (t39 + 0U);
    t8 = (t6 + 0U);
    *((int *)t8) = 30;
    t8 = (t6 + 4U);
    *((int *)t8) = 0;
    t8 = (t6 + 8U);
    *((int *)t8) = -1;
    t4 = (0 - 30);
    t40 = (t4 * -1);
    t40 = (t40 + 1);
    t8 = (t6 + 12U);
    *((unsigned int *)t8) = t40;
    t3 = xsi_base_array_concat(t3, t23, t5, (char)97, t1, t39, (char)99, (unsigned char)2, (char)101);
    t40 = (31U + 1U);
    t32 = (32U != t40);
    if (t32 == 1)
        goto LAB29;

LAB30:    t8 = (t0 + 3072);
    t9 = (t8 + 56U);
    t11 = *((char **)t9);
    t12 = (t11 + 56U);
    t14 = *((char **)t12);
    memcpy(t14, t3, 32U);
    xsi_driver_first_trans_fast_port(t8);
    goto LAB2;

LAB9:    xsi_set_current_line(44, ng0);
    t1 = (t0 + 1192U);
    t2 = *((char **)t1);
    t4 = (31 - 31);
    t30 = (t4 * -1);
    t31 = (1U * t30);
    t38 = (0 + t31);
    t1 = (t2 + t38);
    t32 = *((unsigned char *)t1);
    t3 = (t0 + 1192U);
    t5 = *((char **)t3);
    t40 = (31 - 31);
    t41 = (t40 * 1U);
    t42 = (0 + t41);
    t3 = (t5 + t42);
    t8 = ((IEEE_P_2592010699) + 4024);
    t9 = (t39 + 0U);
    t11 = (t9 + 0U);
    *((int *)t11) = 31;
    t11 = (t9 + 4U);
    *((int *)t11) = 1;
    t11 = (t9 + 8U);
    *((int *)t11) = -1;
    t7 = (1 - 31);
    t43 = (t7 * -1);
    t43 = (t43 + 1);
    t11 = (t9 + 12U);
    *((unsigned int *)t11) = t43;
    t6 = xsi_base_array_concat(t6, t23, t8, (char)99, t32, (char)97, t3, t39, (char)101);
    t43 = (1U + 31U);
    t44 = (32U != t43);
    if (t44 == 1)
        goto LAB31;

LAB32:    t11 = (t0 + 3072);
    t12 = (t11 + 56U);
    t14 = *((char **)t12);
    t15 = (t14 + 56U);
    t17 = *((char **)t15);
    memcpy(t17, t6, 32U);
    xsi_driver_first_trans_fast_port(t11);
    goto LAB2;

LAB18:;
LAB19:    xsi_size_not_matching(32U, t31, 0);
    goto LAB20;

LAB21:    xsi_size_not_matching(32U, t31, 0);
    goto LAB22;

LAB23:    xsi_size_not_matching(32U, t31, 0);
    goto LAB24;

LAB25:    xsi_size_not_matching(32U, t40, 0);
    goto LAB26;

LAB27:    xsi_size_not_matching(32U, t40, 0);
    goto LAB28;

LAB29:    xsi_size_not_matching(32U, t40, 0);
    goto LAB30;

LAB31:    xsi_size_not_matching(32U, t43, 0);
    goto LAB32;

LAB33:    xsi_size_not_matching(32U, t31, 0);
    goto LAB34;

}


extern void work_a_1248124681_1516540902_init()
{
	static char *pe[] = {(void *)work_a_1248124681_1516540902_p_0};
	xsi_register_didat("work_a_1248124681_1516540902", "isim/TestbenchBoard_isim_beh.exe.sim/work/a_1248124681_1516540902.didat");
	xsi_register_executes(pe);
}
