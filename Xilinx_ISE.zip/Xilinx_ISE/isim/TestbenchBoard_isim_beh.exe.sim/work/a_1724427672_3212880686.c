/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "E:/N.I.G.E.-Machine/VHDL/equalZeroComparitor.vhd";
extern char *IEEE_P_0774719531;

unsigned char ieee_p_0774719531_sub_2546418145_2162500114(char *, char *, char *, int );


static void work_a_1724427672_3212880686_p_0(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;

LAB0:    xsi_set_current_line(16, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 4320U);
    t3 = ieee_p_0774719531_sub_2546418145_2162500114(IEEE_P_0774719531, t2, t1, 0);
    if (t3 != 0)
        goto LAB2;

LAB4:    xsi_set_current_line(19, ng0);
    t1 = (t0 + 2752);
    t2 = (t1 + 56U);
    t4 = *((char **)t2);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);

LAB3:    t1 = (t0 + 2672);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(17, ng0);
    t4 = (t0 + 2752);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    *((unsigned char *)t8) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t4);
    goto LAB3;

}


extern void work_a_1724427672_3212880686_init()
{
	static char *pe[] = {(void *)work_a_1724427672_3212880686_p_0};
	xsi_register_didat("work_a_1724427672_3212880686", "isim/TestbenchBoard_isim_beh.exe.sim/work/a_1724427672_3212880686.didat");
	xsi_register_executes(pe);
}
