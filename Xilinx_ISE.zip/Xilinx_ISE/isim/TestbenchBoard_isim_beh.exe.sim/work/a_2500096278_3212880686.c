/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "E:/N.I.G.E.-Machine/VHDL/PS2KeyboardDecoder.vhd";
extern char *IEEE_P_2592010699;
extern char *IEEE_P_3620187407;

unsigned char ieee_p_2592010699_sub_1605435078_503743352(char *, unsigned char , unsigned char );
unsigned char ieee_p_2592010699_sub_1690584930_503743352(char *, unsigned char );
unsigned char ieee_p_2592010699_sub_1744673427_503743352(char *, char *, unsigned int , unsigned int );
unsigned char ieee_p_2592010699_sub_2507238156_503743352(char *, unsigned char , unsigned char );
unsigned char ieee_p_3620187407_sub_2546418145_3965413181(char *, char *, char *, int );
char *ieee_p_3620187407_sub_436279890_3965413181(char *, char *, char *, char *, int );


static void work_a_2500096278_3212880686_p_0(char *t0)
{
    char *t1;
    char *t2;
    unsigned int t3;
    unsigned int t4;
    unsigned int t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;

LAB0:    xsi_set_current_line(26, ng0);

LAB3:    t1 = (t0 + 2472U);
    t2 = *((char **)t1);
    t3 = (10 - 8);
    t4 = (t3 * 1U);
    t5 = (0 + t4);
    t1 = (t2 + t5);
    t6 = (t0 + 5792);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 8U);
    xsi_driver_first_trans_fast_port(t6);

LAB2:    t11 = (t0 + 5632);
    *((int *)t11) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_2500096278_3212880686_p_1(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    unsigned char t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;

LAB0:    xsi_set_current_line(27, ng0);

LAB3:    t1 = (t0 + 1992U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t4 = ieee_p_2592010699_sub_1690584930_503743352(IEEE_P_2592010699, t3);
    t1 = (t0 + 1832U);
    t5 = *((char **)t1);
    t6 = *((unsigned char *)t5);
    t7 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t4, t6);
    t1 = (t0 + 5856);
    t8 = (t1 + 56U);
    t9 = *((char **)t8);
    t10 = (t9 + 56U);
    t11 = *((char **)t10);
    *((unsigned char *)t11) = t7;
    xsi_driver_first_trans_fast(t1);

LAB2:    t12 = (t0 + 5648);
    *((int *)t12) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_2500096278_3212880686_p_2(char *t0)
{
    unsigned char t1;
    unsigned char t2;
    char *t3;
    char *t4;
    int t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned char t9;
    unsigned char t10;
    char *t11;
    char *t12;
    int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned char t17;
    unsigned char t18;
    char *t19;
    char *t20;
    int t21;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    unsigned char t25;
    char *t26;
    char *t27;
    int t28;
    unsigned int t29;
    unsigned int t30;
    unsigned int t31;
    unsigned char t32;
    unsigned char t33;
    char *t34;
    char *t35;
    int t36;
    unsigned int t37;
    unsigned int t38;
    unsigned int t39;
    unsigned char t40;
    unsigned char t41;
    char *t42;
    char *t43;
    int t44;
    unsigned int t45;
    unsigned int t46;
    unsigned int t47;
    unsigned char t48;
    unsigned char t49;
    char *t50;
    char *t51;
    int t52;
    unsigned int t53;
    unsigned int t54;
    unsigned int t55;
    unsigned char t56;
    unsigned char t57;
    char *t58;
    char *t59;
    int t60;
    unsigned int t61;
    unsigned int t62;
    unsigned int t63;
    unsigned char t64;
    unsigned char t65;
    char *t66;
    char *t67;
    int t68;
    unsigned int t69;
    unsigned int t70;
    unsigned int t71;
    unsigned char t72;
    unsigned char t73;
    char *t74;
    char *t75;
    int t76;
    unsigned int t77;
    unsigned int t78;
    unsigned int t79;
    unsigned char t80;
    unsigned char t81;
    char *t82;
    char *t83;
    int t84;
    unsigned int t85;
    unsigned int t86;
    unsigned int t87;
    unsigned char t88;
    unsigned char t89;
    unsigned char t90;
    char *t91;
    char *t92;
    char *t93;
    char *t94;
    char *t95;
    char *t96;
    char *t97;
    char *t98;
    char *t99;
    char *t100;
    char *t101;

LAB0:    xsi_set_current_line(28, ng0);
    t3 = (t0 + 2472U);
    t4 = *((char **)t3);
    t5 = (0 - 10);
    t6 = (t5 * -1);
    t7 = (1U * t6);
    t8 = (0 + t7);
    t3 = (t4 + t8);
    t9 = *((unsigned char *)t3);
    t10 = (t9 == (unsigned char)2);
    if (t10 == 1)
        goto LAB8;

LAB9:    t2 = (unsigned char)0;

LAB10:    if (t2 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB3;

LAB4:
LAB11:    t96 = (t0 + 5920);
    t97 = (t96 + 56U);
    t98 = *((char **)t97);
    t99 = (t98 + 56U);
    t100 = *((char **)t99);
    *((unsigned char *)t100) = (unsigned char)3;
    xsi_driver_first_trans_fast(t96);

LAB2:    t101 = (t0 + 5664);
    *((int *)t101) = 1;

LAB1:    return;
LAB3:    t91 = (t0 + 5920);
    t92 = (t91 + 56U);
    t93 = *((char **)t92);
    t94 = (t93 + 56U);
    t95 = *((char **)t94);
    *((unsigned char *)t95) = (unsigned char)2;
    xsi_driver_first_trans_fast(t91);
    goto LAB2;

LAB5:    t19 = (t0 + 2472U);
    t20 = *((char **)t19);
    t21 = (1 - 10);
    t22 = (t21 * -1);
    t23 = (1U * t22);
    t24 = (0 + t23);
    t19 = (t20 + t24);
    t25 = *((unsigned char *)t19);
    t26 = (t0 + 2472U);
    t27 = *((char **)t26);
    t28 = (2 - 10);
    t29 = (t28 * -1);
    t30 = (1U * t29);
    t31 = (0 + t30);
    t26 = (t27 + t31);
    t32 = *((unsigned char *)t26);
    t33 = ieee_p_2592010699_sub_2507238156_503743352(IEEE_P_2592010699, t25, t32);
    t34 = (t0 + 2472U);
    t35 = *((char **)t34);
    t36 = (3 - 10);
    t37 = (t36 * -1);
    t38 = (1U * t37);
    t39 = (0 + t38);
    t34 = (t35 + t39);
    t40 = *((unsigned char *)t34);
    t41 = ieee_p_2592010699_sub_2507238156_503743352(IEEE_P_2592010699, t33, t40);
    t42 = (t0 + 2472U);
    t43 = *((char **)t42);
    t44 = (4 - 10);
    t45 = (t44 * -1);
    t46 = (1U * t45);
    t47 = (0 + t46);
    t42 = (t43 + t47);
    t48 = *((unsigned char *)t42);
    t49 = ieee_p_2592010699_sub_2507238156_503743352(IEEE_P_2592010699, t41, t48);
    t50 = (t0 + 2472U);
    t51 = *((char **)t50);
    t52 = (5 - 10);
    t53 = (t52 * -1);
    t54 = (1U * t53);
    t55 = (0 + t54);
    t50 = (t51 + t55);
    t56 = *((unsigned char *)t50);
    t57 = ieee_p_2592010699_sub_2507238156_503743352(IEEE_P_2592010699, t49, t56);
    t58 = (t0 + 2472U);
    t59 = *((char **)t58);
    t60 = (6 - 10);
    t61 = (t60 * -1);
    t62 = (1U * t61);
    t63 = (0 + t62);
    t58 = (t59 + t63);
    t64 = *((unsigned char *)t58);
    t65 = ieee_p_2592010699_sub_2507238156_503743352(IEEE_P_2592010699, t57, t64);
    t66 = (t0 + 2472U);
    t67 = *((char **)t66);
    t68 = (7 - 10);
    t69 = (t68 * -1);
    t70 = (1U * t69);
    t71 = (0 + t70);
    t66 = (t67 + t71);
    t72 = *((unsigned char *)t66);
    t73 = ieee_p_2592010699_sub_2507238156_503743352(IEEE_P_2592010699, t65, t72);
    t74 = (t0 + 2472U);
    t75 = *((char **)t74);
    t76 = (8 - 10);
    t77 = (t76 * -1);
    t78 = (1U * t77);
    t79 = (0 + t78);
    t74 = (t75 + t79);
    t80 = *((unsigned char *)t74);
    t81 = ieee_p_2592010699_sub_2507238156_503743352(IEEE_P_2592010699, t73, t80);
    t82 = (t0 + 2472U);
    t83 = *((char **)t82);
    t84 = (9 - 10);
    t85 = (t84 * -1);
    t86 = (1U * t85);
    t87 = (0 + t86);
    t82 = (t83 + t87);
    t88 = *((unsigned char *)t82);
    t89 = ieee_p_2592010699_sub_2507238156_503743352(IEEE_P_2592010699, t81, t88);
    t90 = (t89 == (unsigned char)3);
    t1 = t90;
    goto LAB7;

LAB8:    t11 = (t0 + 2472U);
    t12 = *((char **)t11);
    t13 = (10 - 10);
    t14 = (t13 * -1);
    t15 = (1U * t14);
    t16 = (0 + t15);
    t11 = (t12 + t16);
    t17 = *((unsigned char *)t11);
    t18 = (t17 == (unsigned char)3);
    t2 = t18;
    goto LAB10;

LAB12:    goto LAB2;

}

static void work_a_2500096278_3212880686_p_3(char *t0)
{
    unsigned char t1;
    char *t2;
    char *t3;
    unsigned char t4;
    char *t5;
    char *t6;
    unsigned char t7;
    unsigned char t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;

LAB0:    xsi_set_current_line(31, ng0);
    t2 = (t0 + 2152U);
    t3 = *((char **)t2);
    t2 = (t0 + 8888U);
    t4 = ieee_p_3620187407_sub_2546418145_3965413181(IEEE_P_3620187407, t3, t2, 11);
    if (t4 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB3;

LAB4:
LAB8:    t13 = (t0 + 5984);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    t16 = (t15 + 56U);
    t17 = *((char **)t16);
    *((unsigned char *)t17) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t13);

LAB2:    t18 = (t0 + 5680);
    *((int *)t18) = 1;

LAB1:    return;
LAB3:    t5 = (t0 + 5984);
    t9 = (t5 + 56U);
    t10 = *((char **)t9);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    *((unsigned char *)t12) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t5);
    goto LAB2;

LAB5:    t5 = (t0 + 2792U);
    t6 = *((char **)t5);
    t7 = *((unsigned char *)t6);
    t8 = (t7 == (unsigned char)2);
    t1 = t8;
    goto LAB7;

LAB9:    goto LAB2;

}

static void work_a_2500096278_3212880686_p_4(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    unsigned char t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    int t9;
    int t10;
    char *t11;
    char *t12;
    char *t13;

LAB0:    t1 = (t0 + 5064U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(36, ng0);

LAB6:    t2 = (t0 + 5696);
    *((int *)t2) = 1;
    *((char **)t1) = &&LAB7;

LAB1:    return;
LAB4:    t5 = (t0 + 5696);
    *((int *)t5) = 0;
    xsi_set_current_line(37, ng0);
    t2 = (t0 + 1992U);
    t3 = *((char **)t2);
    t4 = *((unsigned char *)t3);
    t2 = (t0 + 1192U);
    t5 = *((char **)t2);
    t6 = *((unsigned char *)t5);
    t7 = (t4 == t6);
    if (t7 != 0)
        goto LAB8;

LAB10:    xsi_set_current_line(40, ng0);
    t2 = (t0 + 3088U);
    t3 = *((char **)t2);
    t9 = *((int *)t3);
    t10 = (t9 + 1);
    t2 = (t0 + 3088U);
    t5 = *((char **)t2);
    t2 = (t5 + 0);
    *((int *)t2) = t10;
    xsi_set_current_line(41, ng0);
    t2 = (t0 + 3088U);
    t3 = *((char **)t2);
    t9 = *((int *)t3);
    t4 = (t9 == 127);
    if (t4 != 0)
        goto LAB11;

LAB13:
LAB12:
LAB9:    goto LAB2;

LAB5:    t3 = (t0 + 992U);
    t4 = ieee_p_2592010699_sub_1744673427_503743352(IEEE_P_2592010699, t3, 0U, 0U);
    if (t4 == 1)
        goto LAB4;
    else
        goto LAB6;

LAB7:    goto LAB5;

LAB8:    xsi_set_current_line(38, ng0);
    t2 = (t0 + 3088U);
    t8 = *((char **)t2);
    t2 = (t8 + 0);
    *((int *)t2) = 0;
    goto LAB9;

LAB11:    xsi_set_current_line(42, ng0);
    t2 = (t0 + 1192U);
    t5 = *((char **)t2);
    t6 = *((unsigned char *)t5);
    t2 = (t0 + 6048);
    t8 = (t2 + 56U);
    t11 = *((char **)t8);
    t12 = (t11 + 56U);
    t13 = *((char **)t12);
    *((unsigned char *)t13) = t6;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(43, ng0);
    t2 = (t0 + 3088U);
    t3 = *((char **)t2);
    t2 = (t3 + 0);
    *((int *)t2) = 0;
    goto LAB12;

}

static void work_a_2500096278_3212880686_p_5(char *t0)
{
    char t12[16];
    char t20[16];
    char *t1;
    char *t2;
    char *t3;
    unsigned char t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    unsigned char t9;
    char *t10;
    char *t11;
    unsigned int t13;
    unsigned int t14;
    char *t15;
    unsigned char t16;
    char *t17;
    char *t18;
    unsigned int t19;
    int t21;
    unsigned int t22;
    unsigned char t23;
    char *t24;

LAB0:    t1 = (t0 + 5312U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(50, ng0);

LAB6:    t2 = (t0 + 5712);
    *((int *)t2) = 1;
    *((char **)t1) = &&LAB7;

LAB1:    return;
LAB4:    t5 = (t0 + 5712);
    *((int *)t5) = 0;
    xsi_set_current_line(52, ng0);
    t2 = (t0 + 1992U);
    t3 = *((char **)t2);
    t4 = *((unsigned char *)t3);
    t2 = (t0 + 6112);
    t5 = (t2 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    *((unsigned char *)t8) = t4;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(54, ng0);
    t2 = (t0 + 1992U);
    t3 = *((char **)t2);
    t4 = *((unsigned char *)t3);
    t9 = (t4 == (unsigned char)2);
    if (t9 != 0)
        goto LAB8;

LAB10:    xsi_set_current_line(57, ng0);
    t2 = (t0 + 2312U);
    t3 = *((char **)t2);
    t2 = (t0 + 8904U);
    t5 = ieee_p_3620187407_sub_436279890_3965413181(IEEE_P_3620187407, t12, t3, t2, 1);
    t6 = (t12 + 12U);
    t13 = *((unsigned int *)t6);
    t14 = (1U * t13);
    t4 = (13U != t14);
    if (t4 == 1)
        goto LAB11;

LAB12:    t7 = (t0 + 6176);
    t8 = (t7 + 56U);
    t10 = *((char **)t8);
    t11 = (t10 + 56U);
    t15 = *((char **)t11);
    memcpy(t15, t5, 13U);
    xsi_driver_first_trans_fast(t7);

LAB9:    xsi_set_current_line(60, ng0);
    t2 = (t0 + 2152U);
    t3 = *((char **)t2);
    t2 = (t0 + 8888U);
    t9 = ieee_p_3620187407_sub_2546418145_3965413181(IEEE_P_3620187407, t3, t2, 11);
    if (t9 == 1)
        goto LAB16;

LAB17:    t5 = (t0 + 2312U);
    t6 = *((char **)t5);
    t5 = (t0 + 8904U);
    t16 = ieee_p_3620187407_sub_2546418145_3965413181(IEEE_P_3620187407, t6, t5, 8191);
    t4 = t16;

LAB18:    if (t4 != 0)
        goto LAB13;

LAB15:    t2 = (t0 + 2632U);
    t3 = *((char **)t2);
    t4 = *((unsigned char *)t3);
    t9 = (t4 == (unsigned char)3);
    if (t9 != 0)
        goto LAB19;

LAB20:
LAB14:    xsi_set_current_line(66, ng0);
    t2 = (t0 + 2632U);
    t3 = *((char **)t2);
    t4 = *((unsigned char *)t3);
    t9 = (t4 == (unsigned char)3);
    if (t9 != 0)
        goto LAB23;

LAB25:
LAB24:    goto LAB2;

LAB5:    t3 = (t0 + 992U);
    t4 = ieee_p_2592010699_sub_1744673427_503743352(IEEE_P_2592010699, t3, 0U, 0U);
    if (t4 == 1)
        goto LAB4;
    else
        goto LAB6;

LAB7:    goto LAB5;

LAB8:    xsi_set_current_line(55, ng0);
    t2 = xsi_get_transient_memory(13U);
    memset(t2, 0, 13U);
    t5 = t2;
    memset(t5, (unsigned char)2, 13U);
    t6 = (t0 + 6176);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t10 = (t8 + 56U);
    t11 = *((char **)t10);
    memcpy(t11, t2, 13U);
    xsi_driver_first_trans_fast(t6);
    goto LAB9;

LAB11:    xsi_size_not_matching(13U, t14, 0);
    goto LAB12;

LAB13:    xsi_set_current_line(61, ng0);
    t7 = xsi_get_transient_memory(4U);
    memset(t7, 0, 4U);
    t8 = t7;
    memset(t8, (unsigned char)2, 4U);
    t10 = (t0 + 6240);
    t11 = (t10 + 56U);
    t15 = *((char **)t11);
    t17 = (t15 + 56U);
    t18 = *((char **)t17);
    memcpy(t18, t7, 4U);
    xsi_driver_first_trans_fast(t10);
    goto LAB14;

LAB16:    t4 = (unsigned char)1;
    goto LAB18;

LAB19:    xsi_set_current_line(63, ng0);
    t2 = (t0 + 2152U);
    t5 = *((char **)t2);
    t2 = (t0 + 8888U);
    t6 = ieee_p_3620187407_sub_436279890_3965413181(IEEE_P_3620187407, t12, t5, t2, 1);
    t7 = (t12 + 12U);
    t13 = *((unsigned int *)t7);
    t14 = (1U * t13);
    t16 = (4U != t14);
    if (t16 == 1)
        goto LAB21;

LAB22:    t8 = (t0 + 6240);
    t10 = (t8 + 56U);
    t11 = *((char **)t10);
    t15 = (t11 + 56U);
    t17 = *((char **)t15);
    memcpy(t17, t6, 4U);
    xsi_driver_first_trans_fast(t8);
    goto LAB14;

LAB21:    xsi_size_not_matching(4U, t14, 0);
    goto LAB22;

LAB23:    xsi_set_current_line(67, ng0);
    t2 = (t0 + 1352U);
    t5 = *((char **)t2);
    t16 = *((unsigned char *)t5);
    t2 = (t0 + 2472U);
    t6 = *((char **)t2);
    t13 = (10 - 10);
    t14 = (t13 * 1U);
    t19 = (0 + t14);
    t2 = (t6 + t19);
    t8 = ((IEEE_P_2592010699) + 4024);
    t10 = (t20 + 0U);
    t11 = (t10 + 0U);
    *((int *)t11) = 10;
    t11 = (t10 + 4U);
    *((int *)t11) = 1;
    t11 = (t10 + 8U);
    *((int *)t11) = -1;
    t21 = (1 - 10);
    t22 = (t21 * -1);
    t22 = (t22 + 1);
    t11 = (t10 + 12U);
    *((unsigned int *)t11) = t22;
    t7 = xsi_base_array_concat(t7, t12, t8, (char)99, t16, (char)97, t2, t20, (char)101);
    t22 = (1U + 10U);
    t23 = (11U != t22);
    if (t23 == 1)
        goto LAB26;

LAB27:    t11 = (t0 + 6304);
    t15 = (t11 + 56U);
    t17 = *((char **)t15);
    t18 = (t17 + 56U);
    t24 = *((char **)t18);
    memcpy(t24, t7, 11U);
    xsi_driver_first_trans_fast(t11);
    goto LAB24;

LAB26:    xsi_size_not_matching(11U, t22, 0);
    goto LAB27;

}


extern void work_a_2500096278_3212880686_init()
{
	static char *pe[] = {(void *)work_a_2500096278_3212880686_p_0,(void *)work_a_2500096278_3212880686_p_1,(void *)work_a_2500096278_3212880686_p_2,(void *)work_a_2500096278_3212880686_p_3,(void *)work_a_2500096278_3212880686_p_4,(void *)work_a_2500096278_3212880686_p_5};
	xsi_register_didat("work_a_2500096278_3212880686", "isim/TestbenchBoard_isim_beh.exe.sim/work/a_2500096278_3212880686.didat");
	xsi_register_executes(pe);
}
