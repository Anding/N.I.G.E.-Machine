/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "E:/N.I.G.E.-Machine/VHDL/TestbenchBoard.vhd";
extern char *STD_STANDARD;
extern char *IEEE_P_2592010699;

unsigned char ieee_p_2592010699_sub_2507238156_503743352(char *, unsigned char , unsigned char );


static void work_a_4037138396_2372691052_p_0(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;

LAB0:    xsi_set_current_line(170, ng0);

LAB3:    t1 = (t0 + 3752U);
    t2 = *((char **)t1);
    t1 = (t0 + 9760);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    memcpy(t6, t2, 23U);
    xsi_driver_first_trans_fast(t1);

LAB2:    t7 = (t0 + 9632);
    *((int *)t7) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_4037138396_2372691052_p_1(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;

LAB0:    xsi_set_current_line(171, ng0);

LAB3:    t1 = (t0 + 6312U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 9824);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = t3;
    xsi_driver_first_trans_fast(t1);

LAB2:    t8 = (t0 + 9648);
    *((int *)t8) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_4037138396_2372691052_p_2(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;

LAB0:    xsi_set_current_line(172, ng0);

LAB3:    t1 = (t0 + 6472U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 9888);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = t3;
    xsi_driver_first_trans_fast(t1);

LAB2:    t8 = (t0 + 9664);
    *((int *)t8) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_4037138396_2372691052_p_3(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;

LAB0:    xsi_set_current_line(173, ng0);

LAB3:    t1 = (t0 + 6632U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 9952);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = t3;
    xsi_driver_first_trans_fast(t1);

LAB2:    t8 = (t0 + 9680);
    *((int *)t8) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_4037138396_2372691052_p_4(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    int64 t7;
    int64 t8;

LAB0:    t1 = (t0 + 9064U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(178, ng0);
    t2 = (t0 + 10016);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(179, ng0);
    t2 = (t0 + 7088U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t8 = (t7 / 2);
    t2 = (t0 + 8872);
    xsi_process_wait(t2, t8);

LAB6:    *((char **)t1) = &&LAB7;

LAB1:    return;
LAB4:    xsi_set_current_line(180, ng0);
    t2 = (t0 + 10016);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(181, ng0);
    t2 = (t0 + 7088U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t8 = (t7 / 2);
    t2 = (t0 + 8872);
    xsi_process_wait(t2, t8);

LAB10:    *((char **)t1) = &&LAB11;
    goto LAB1;

LAB5:    goto LAB4;

LAB7:    goto LAB5;

LAB8:    goto LAB2;

LAB9:    goto LAB8;

LAB11:    goto LAB9;

}

void work_a_4037138396_2372691052_sub_3023655556_2855802964(char *t0, char *t1, char *t2, unsigned int t3, unsigned int t4, char *t5, char *t6, char *t7)
{
    char t8[128];
    char t9[24];
    char t15[8];
    int64 t10;
    int64 t11;
    char *t12;
    char *t13;
    char *t14;
    char *t16;
    char *t17;
    char *t18;
    unsigned char t19;
    char *t20;
    unsigned int t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;
    char *t28;
    char *t29;
    char *t30;
    int t31;
    int t32;
    int t33;
    int t34;
    int t35;
    int t36;
    int t37;
    int t38;
    int t39;
    int t40;
    int t41;
    unsigned int t42;
    unsigned int t43;
    unsigned int t44;

LAB0:    t10 = (1.0000000000000000 * 1000000000000LL);
    t11 = (t10 / 57600);
    t12 = (t8 + 4U);
    t13 = ((STD_STANDARD) + 576);
    t14 = (t12 + 88U);
    *((char **)t14) = t13;
    t16 = (t12 + 56U);
    *((char **)t16) = t15;
    *((int64 *)t15) = t11;
    t17 = (t12 + 80U);
    *((unsigned int *)t17) = 8U;
    t18 = (t9 + 4U);
    t19 = (t6 != 0);
    if (t19 == 1)
        goto LAB3;

LAB2:    t20 = (t9 + 12U);
    *((char **)t20) = t7;
    t21 = (0 + t3);
    t22 = (t5 + 56U);
    t23 = *((char **)t22);
    t24 = (t23 + 56U);
    t25 = *((char **)t24);
    *((unsigned char *)t25) = (unsigned char)2;
    xsi_driver_first_trans_delta(t5, t21, 1, 0LL);
    t13 = (t12 + 56U);
    t14 = *((char **)t13);
    t10 = *((int64 *)t14);
    xsi_process_wait(t1, t10);

LAB7:    t13 = (t1 + 88U);
    t16 = *((char **)t13);
    t17 = (t16 + 2480U);
    *((unsigned int *)t17) = 1U;
    t22 = (t1 + 88U);
    t23 = *((char **)t22);
    t24 = (t23 + 0U);
    getcontext(t24);
    t25 = (t1 + 88U);
    t26 = *((char **)t25);
    t27 = (t26 + 2480U);
    t21 = *((unsigned int *)t27);
    if (t21 == 1)
        goto LAB8;

LAB9:    t28 = (t1 + 88U);
    t29 = *((char **)t28);
    t30 = (t29 + 2480U);
    *((unsigned int *)t30) = 3U;

LAB5:
LAB6:
LAB4:    t13 = (t7 + 8U);
    t31 = *((int *)t13);
    t32 = (t31 * -1);
    t14 = (t7 + 0U);
    t33 = *((int *)t14);
    t16 = (t7 + 4U);
    t34 = *((int *)t16);
    t35 = t34;
    t36 = t33;

LAB10:    t37 = (t36 * t32);
    t38 = (t35 * t32);
    if (t38 <= t37)
        goto LAB11;

LAB13:    t21 = (0 + t3);
    t13 = (t5 + 56U);
    t14 = *((char **)t13);
    t16 = (t14 + 56U);
    t17 = *((char **)t16);
    *((unsigned char *)t17) = (unsigned char)3;
    xsi_driver_first_trans_delta(t5, t21, 1, 0LL);
    t13 = (t12 + 56U);
    t14 = *((char **)t13);
    t10 = *((int64 *)t14);
    xsi_process_wait(t1, t10);

LAB24:    t13 = (t1 + 88U);
    t16 = *((char **)t13);
    t17 = (t16 + 2480U);
    *((unsigned int *)t17) = 1U;
    t22 = (t1 + 88U);
    t23 = *((char **)t22);
    t24 = (t23 + 0U);
    getcontext(t24);
    t25 = (t1 + 88U);
    t26 = *((char **)t25);
    t27 = (t26 + 2480U);
    t21 = *((unsigned int *)t27);
    if (t21 == 1)
        goto LAB25;

LAB26:    t28 = (t1 + 88U);
    t29 = *((char **)t28);
    t30 = (t29 + 2480U);
    *((unsigned int *)t30) = 3U;

LAB22:
LAB23:
LAB21:
LAB1:    return;
LAB3:    *((char **)t18) = t6;
    goto LAB2;

LAB8:    xsi_saveStackAndSuspend(t1);
    goto LAB9;

LAB11:    t17 = (t7 + 0U);
    t39 = *((int *)t17);
    t22 = (t7 + 8U);
    t40 = *((int *)t22);
    t41 = (t35 - t39);
    t21 = (t41 * t40);
    t42 = (1U * t21);
    t43 = (0 + t42);
    t23 = (t6 + t43);
    t19 = *((unsigned char *)t23);
    t44 = (0 + t3);
    t24 = (t5 + 56U);
    t25 = *((char **)t24);
    t26 = (t25 + 56U);
    t27 = *((char **)t26);
    *((unsigned char *)t27) = t19;
    xsi_driver_first_trans_delta(t5, t44, 1, 0LL);
    t13 = (t12 + 56U);
    t14 = *((char **)t13);
    t10 = *((int64 *)t14);
    xsi_process_wait(t1, t10);

LAB17:    t13 = (t1 + 88U);
    t16 = *((char **)t13);
    t17 = (t16 + 2480U);
    *((unsigned int *)t17) = 1U;
    t22 = (t1 + 88U);
    t23 = *((char **)t22);
    t24 = (t23 + 0U);
    getcontext(t24);
    t25 = (t1 + 88U);
    t26 = *((char **)t25);
    t27 = (t26 + 2480U);
    t21 = *((unsigned int *)t27);
    if (t21 == 1)
        goto LAB18;

LAB19:    t28 = (t1 + 88U);
    t29 = *((char **)t28);
    t30 = (t29 + 2480U);
    *((unsigned int *)t30) = 3U;

LAB15:
LAB16:
LAB14:
LAB12:    if (t35 == t36)
        goto LAB13;

LAB20:    t31 = (t35 + t32);
    t35 = t31;
    goto LAB10;

LAB18:    xsi_saveStackAndSuspend(t1);
    goto LAB19;

LAB25:    xsi_saveStackAndSuspend(t1);
    goto LAB26;

}

void work_a_4037138396_2372691052_sub_3715734401_2855802964(char *t0, char *t1, char *t2, unsigned int t3, unsigned int t4, char *t5, char *t6, unsigned int t7, unsigned int t8, char *t9, char *t10)
{
    char t11[128];
    char t12[24];
    char t13[16];
    char t22[8];
    char *t14;
    char *t15;
    int t16;
    unsigned int t17;
    int64 t18;
    int64 t19;
    char *t20;
    char *t21;
    char *t23;
    char *t24;
    char *t25;
    unsigned char t26;
    char *t27;
    char *t28;
    char *t29;
    char *t30;
    char *t31;
    char *t32;
    char *t33;
    char *t34;
    char *t35;
    int t36;
    int t37;
    int t38;
    int t39;
    int t40;
    int t41;
    int t42;
    int t43;
    int t44;
    int t45;
    unsigned int t46;
    unsigned int t47;
    unsigned int t48;
    unsigned int t49;
    unsigned int t50;
    unsigned char t51;
    unsigned char t52;
    unsigned int t53;
    unsigned int t54;
    unsigned int t55;
    unsigned char t56;
    unsigned char t57;
    int t58;
    unsigned int t59;
    unsigned int t60;
    unsigned int t61;
    unsigned char t62;
    unsigned char t63;
    int t64;
    char *t65;
    int t66;
    int t67;
    unsigned int t68;
    unsigned int t69;
    unsigned int t70;
    char *t71;
    unsigned char t72;
    unsigned char t73;
    char *t74;
    int t75;
    char *t76;
    int t77;
    int t78;
    unsigned int t79;
    unsigned int t80;
    unsigned int t81;
    char *t82;
    unsigned char t83;
    unsigned char t84;
    char *t85;
    int t86;
    char *t87;
    int t88;
    int t89;
    unsigned int t90;
    unsigned int t91;
    unsigned int t92;
    char *t93;
    unsigned char t94;
    unsigned char t95;
    char *t96;
    int t97;
    char *t98;
    int t99;
    int t100;
    unsigned int t101;
    unsigned int t102;
    unsigned int t103;
    char *t104;
    unsigned char t105;
    unsigned char t106;
    unsigned char t107;
    unsigned int t108;
    char *t109;
    char *t110;
    char *t111;
    char *t112;

LAB0:    t14 = (t13 + 0U);
    t15 = (t14 + 0U);
    *((int *)t15) = 7;
    t15 = (t14 + 4U);
    *((int *)t15) = 0;
    t15 = (t14 + 8U);
    *((int *)t15) = -1;
    t16 = (0 - 7);
    t17 = (t16 * -1);
    t17 = (t17 + 1);
    t15 = (t14 + 12U);
    *((unsigned int *)t15) = t17;
    t18 = (1.0000000000000000 * 1000000000000LL);
    t19 = (t18 / 24000);
    t15 = (t11 + 4U);
    t20 = ((STD_STANDARD) + 576);
    t21 = (t15 + 88U);
    *((char **)t21) = t20;
    t23 = (t15 + 56U);
    *((char **)t23) = t22;
    *((int64 *)t22) = t19;
    t24 = (t15 + 80U);
    *((unsigned int *)t24) = 8U;
    t25 = (t12 + 4U);
    t26 = (t10 != 0);
    if (t26 == 1)
        goto LAB3;

LAB2:    t27 = (t12 + 12U);
    *((char **)t27) = t13;
    t17 = (0 + t7);
    t28 = (t9 + 56U);
    t29 = *((char **)t28);
    t30 = (t29 + 56U);
    t31 = *((char **)t30);
    *((unsigned char *)t31) = (unsigned char)2;
    xsi_driver_first_trans_delta(t9, t17, 1, 0LL);
    t14 = (t15 + 56U);
    t20 = *((char **)t14);
    t18 = *((int64 *)t20);
    xsi_process_wait(t1, t18);

LAB7:    t14 = (t1 + 88U);
    t21 = *((char **)t14);
    t23 = (t21 + 2480U);
    *((unsigned int *)t23) = 1U;
    t24 = (t1 + 88U);
    t28 = *((char **)t24);
    t29 = (t28 + 0U);
    getcontext(t29);
    t30 = (t1 + 88U);
    t31 = *((char **)t30);
    t32 = (t31 + 2480U);
    t17 = *((unsigned int *)t32);
    if (t17 == 1)
        goto LAB8;

LAB9:    t33 = (t1 + 88U);
    t34 = *((char **)t33);
    t35 = (t34 + 2480U);
    *((unsigned int *)t35) = 3U;

LAB5:
LAB6:
LAB4:    t17 = (0 + t3);
    t14 = (t5 + 56U);
    t20 = *((char **)t14);
    t21 = (t20 + 56U);
    t23 = *((char **)t21);
    *((unsigned char *)t23) = (unsigned char)2;
    xsi_driver_first_trans_delta(t5, t17, 1, 0LL);
    t14 = (t15 + 56U);
    t20 = *((char **)t14);
    t18 = *((int64 *)t20);
    xsi_process_wait(t1, t18);

LAB13:    t14 = (t1 + 88U);
    t21 = *((char **)t14);
    t23 = (t21 + 2480U);
    *((unsigned int *)t23) = 1U;
    t24 = (t1 + 88U);
    t28 = *((char **)t24);
    t29 = (t28 + 0U);
    getcontext(t29);
    t30 = (t1 + 88U);
    t31 = *((char **)t30);
    t32 = (t31 + 2480U);
    t17 = *((unsigned int *)t32);
    if (t17 == 1)
        goto LAB14;

LAB15:    t33 = (t1 + 88U);
    t34 = *((char **)t33);
    t35 = (t34 + 2480U);
    *((unsigned int *)t35) = 3U;

LAB11:
LAB12:
LAB10:    t17 = (0 + t3);
    t14 = (t5 + 56U);
    t20 = *((char **)t14);
    t21 = (t20 + 56U);
    t23 = *((char **)t21);
    *((unsigned char *)t23) = (unsigned char)3;
    xsi_driver_first_trans_delta(t5, t17, 1, 0LL);
    t14 = (t13 + 8U);
    t16 = *((int *)t14);
    t36 = (t16 * -1);
    t20 = (t13 + 0U);
    t37 = *((int *)t20);
    t21 = (t13 + 4U);
    t38 = *((int *)t21);
    t39 = t38;
    t40 = t37;

LAB16:    t41 = (t40 * t36);
    t42 = (t39 * t36);
    if (t42 <= t41)
        goto LAB17;

LAB19:    t14 = (t13 + 0U);
    t16 = *((int *)t14);
    t20 = (t13 + 8U);
    t36 = *((int *)t20);
    t37 = (0 - t16);
    t17 = (t37 * t36);
    t46 = (1U * t17);
    t47 = (0 + t46);
    t21 = (t10 + t47);
    t26 = *((unsigned char *)t21);
    t23 = (t13 + 0U);
    t38 = *((int *)t23);
    t24 = (t13 + 8U);
    t39 = *((int *)t24);
    t40 = (1 - t38);
    t48 = (t40 * t39);
    t49 = (1U * t48);
    t50 = (0 + t49);
    t28 = (t10 + t50);
    t51 = *((unsigned char *)t28);
    t52 = ieee_p_2592010699_sub_2507238156_503743352(IEEE_P_2592010699, t26, t51);
    t29 = (t13 + 0U);
    t41 = *((int *)t29);
    t30 = (t13 + 8U);
    t42 = *((int *)t30);
    t43 = (2 - t41);
    t53 = (t43 * t42);
    t54 = (1U * t53);
    t55 = (0 + t54);
    t31 = (t10 + t55);
    t56 = *((unsigned char *)t31);
    t57 = ieee_p_2592010699_sub_2507238156_503743352(IEEE_P_2592010699, t52, t56);
    t32 = (t13 + 0U);
    t44 = *((int *)t32);
    t33 = (t13 + 8U);
    t45 = *((int *)t33);
    t58 = (3 - t44);
    t59 = (t58 * t45);
    t60 = (1U * t59);
    t61 = (0 + t60);
    t34 = (t10 + t61);
    t62 = *((unsigned char *)t34);
    t63 = ieee_p_2592010699_sub_2507238156_503743352(IEEE_P_2592010699, t57, t62);
    t35 = (t13 + 0U);
    t64 = *((int *)t35);
    t65 = (t13 + 8U);
    t66 = *((int *)t65);
    t67 = (4 - t64);
    t68 = (t67 * t66);
    t69 = (1U * t68);
    t70 = (0 + t69);
    t71 = (t10 + t70);
    t72 = *((unsigned char *)t71);
    t73 = ieee_p_2592010699_sub_2507238156_503743352(IEEE_P_2592010699, t63, t72);
    t74 = (t13 + 0U);
    t75 = *((int *)t74);
    t76 = (t13 + 8U);
    t77 = *((int *)t76);
    t78 = (5 - t75);
    t79 = (t78 * t77);
    t80 = (1U * t79);
    t81 = (0 + t80);
    t82 = (t10 + t81);
    t83 = *((unsigned char *)t82);
    t84 = ieee_p_2592010699_sub_2507238156_503743352(IEEE_P_2592010699, t73, t83);
    t85 = (t13 + 0U);
    t86 = *((int *)t85);
    t87 = (t13 + 8U);
    t88 = *((int *)t87);
    t89 = (6 - t86);
    t90 = (t89 * t88);
    t91 = (1U * t90);
    t92 = (0 + t91);
    t93 = (t10 + t92);
    t94 = *((unsigned char *)t93);
    t95 = ieee_p_2592010699_sub_2507238156_503743352(IEEE_P_2592010699, t84, t94);
    t96 = (t13 + 0U);
    t97 = *((int *)t96);
    t98 = (t13 + 8U);
    t99 = *((int *)t98);
    t100 = (7 - t97);
    t101 = (t100 * t99);
    t102 = (1U * t101);
    t103 = (0 + t102);
    t104 = (t10 + t103);
    t105 = *((unsigned char *)t104);
    t106 = ieee_p_2592010699_sub_2507238156_503743352(IEEE_P_2592010699, t95, t105);
    t107 = ieee_p_2592010699_sub_2507238156_503743352(IEEE_P_2592010699, t106, (unsigned char)3);
    t108 = (0 + t7);
    t109 = (t9 + 56U);
    t110 = *((char **)t109);
    t111 = (t110 + 56U);
    t112 = *((char **)t111);
    *((unsigned char *)t112) = t107;
    xsi_driver_first_trans_delta(t9, t108, 1, 0LL);
    t14 = (t15 + 56U);
    t20 = *((char **)t14);
    t18 = *((int64 *)t20);
    xsi_process_wait(t1, t18);

LAB36:    t14 = (t1 + 88U);
    t21 = *((char **)t14);
    t23 = (t21 + 2480U);
    *((unsigned int *)t23) = 1U;
    t24 = (t1 + 88U);
    t28 = *((char **)t24);
    t29 = (t28 + 0U);
    getcontext(t29);
    t30 = (t1 + 88U);
    t31 = *((char **)t30);
    t32 = (t31 + 2480U);
    t17 = *((unsigned int *)t32);
    if (t17 == 1)
        goto LAB37;

LAB38:    t33 = (t1 + 88U);
    t34 = *((char **)t33);
    t35 = (t34 + 2480U);
    *((unsigned int *)t35) = 3U;

LAB34:
LAB35:
LAB33:    t17 = (0 + t3);
    t14 = (t5 + 56U);
    t20 = *((char **)t14);
    t21 = (t20 + 56U);
    t23 = *((char **)t21);
    *((unsigned char *)t23) = (unsigned char)2;
    xsi_driver_first_trans_delta(t5, t17, 1, 0LL);
    t14 = (t15 + 56U);
    t20 = *((char **)t14);
    t18 = *((int64 *)t20);
    xsi_process_wait(t1, t18);

LAB42:    t14 = (t1 + 88U);
    t21 = *((char **)t14);
    t23 = (t21 + 2480U);
    *((unsigned int *)t23) = 1U;
    t24 = (t1 + 88U);
    t28 = *((char **)t24);
    t29 = (t28 + 0U);
    getcontext(t29);
    t30 = (t1 + 88U);
    t31 = *((char **)t30);
    t32 = (t31 + 2480U);
    t17 = *((unsigned int *)t32);
    if (t17 == 1)
        goto LAB43;

LAB44:    t33 = (t1 + 88U);
    t34 = *((char **)t33);
    t35 = (t34 + 2480U);
    *((unsigned int *)t35) = 3U;

LAB40:
LAB41:
LAB39:    t17 = (0 + t3);
    t14 = (t5 + 56U);
    t20 = *((char **)t14);
    t21 = (t20 + 56U);
    t23 = *((char **)t21);
    *((unsigned char *)t23) = (unsigned char)3;
    xsi_driver_first_trans_delta(t5, t17, 1, 0LL);
    t17 = (0 + t7);
    t14 = (t9 + 56U);
    t20 = *((char **)t14);
    t21 = (t20 + 56U);
    t23 = *((char **)t21);
    *((unsigned char *)t23) = (unsigned char)3;
    xsi_driver_first_trans_delta(t9, t17, 1, 0LL);
    t14 = (t15 + 56U);
    t20 = *((char **)t14);
    t18 = *((int64 *)t20);
    xsi_process_wait(t1, t18);

LAB48:    t14 = (t1 + 88U);
    t21 = *((char **)t14);
    t23 = (t21 + 2480U);
    *((unsigned int *)t23) = 1U;
    t24 = (t1 + 88U);
    t28 = *((char **)t24);
    t29 = (t28 + 0U);
    getcontext(t29);
    t30 = (t1 + 88U);
    t31 = *((char **)t30);
    t32 = (t31 + 2480U);
    t17 = *((unsigned int *)t32);
    if (t17 == 1)
        goto LAB49;

LAB50:    t33 = (t1 + 88U);
    t34 = *((char **)t33);
    t35 = (t34 + 2480U);
    *((unsigned int *)t35) = 3U;

LAB46:
LAB47:
LAB45:    t17 = (0 + t3);
    t14 = (t5 + 56U);
    t20 = *((char **)t14);
    t21 = (t20 + 56U);
    t23 = *((char **)t21);
    *((unsigned char *)t23) = (unsigned char)2;
    xsi_driver_first_trans_delta(t5, t17, 1, 0LL);
    t14 = (t15 + 56U);
    t20 = *((char **)t14);
    t18 = *((int64 *)t20);
    xsi_process_wait(t1, t18);

LAB54:    t14 = (t1 + 88U);
    t21 = *((char **)t14);
    t23 = (t21 + 2480U);
    *((unsigned int *)t23) = 1U;
    t24 = (t1 + 88U);
    t28 = *((char **)t24);
    t29 = (t28 + 0U);
    getcontext(t29);
    t30 = (t1 + 88U);
    t31 = *((char **)t30);
    t32 = (t31 + 2480U);
    t17 = *((unsigned int *)t32);
    if (t17 == 1)
        goto LAB55;

LAB56:    t33 = (t1 + 88U);
    t34 = *((char **)t33);
    t35 = (t34 + 2480U);
    *((unsigned int *)t35) = 3U;

LAB52:
LAB53:
LAB51:    t17 = (0 + t3);
    t14 = (t5 + 56U);
    t20 = *((char **)t14);
    t21 = (t20 + 56U);
    t23 = *((char **)t21);
    *((unsigned char *)t23) = (unsigned char)3;
    xsi_driver_first_trans_delta(t5, t17, 1, 0LL);

LAB1:    return;
LAB3:    *((char **)t25) = t10;
    goto LAB2;

LAB8:    xsi_saveStackAndSuspend(t1);
    goto LAB9;

LAB14:    xsi_saveStackAndSuspend(t1);
    goto LAB15;

LAB17:    t23 = (t13 + 0U);
    t43 = *((int *)t23);
    t24 = (t13 + 8U);
    t44 = *((int *)t24);
    t45 = (t39 - t43);
    t17 = (t45 * t44);
    t46 = (1U * t17);
    t47 = (0 + t46);
    t28 = (t10 + t47);
    t26 = *((unsigned char *)t28);
    t48 = (0 + t7);
    t29 = (t9 + 56U);
    t30 = *((char **)t29);
    t31 = (t30 + 56U);
    t32 = *((char **)t31);
    *((unsigned char *)t32) = t26;
    xsi_driver_first_trans_delta(t9, t48, 1, 0LL);
    t14 = (t15 + 56U);
    t20 = *((char **)t14);
    t18 = *((int64 *)t20);
    xsi_process_wait(t1, t18);

LAB23:    t14 = (t1 + 88U);
    t21 = *((char **)t14);
    t23 = (t21 + 2480U);
    *((unsigned int *)t23) = 1U;
    t24 = (t1 + 88U);
    t28 = *((char **)t24);
    t29 = (t28 + 0U);
    getcontext(t29);
    t30 = (t1 + 88U);
    t31 = *((char **)t30);
    t32 = (t31 + 2480U);
    t17 = *((unsigned int *)t32);
    if (t17 == 1)
        goto LAB24;

LAB25:    t33 = (t1 + 88U);
    t34 = *((char **)t33);
    t35 = (t34 + 2480U);
    *((unsigned int *)t35) = 3U;

LAB21:
LAB22:
LAB20:    t17 = (0 + t3);
    t14 = (t5 + 56U);
    t20 = *((char **)t14);
    t21 = (t20 + 56U);
    t23 = *((char **)t21);
    *((unsigned char *)t23) = (unsigned char)2;
    xsi_driver_first_trans_delta(t5, t17, 1, 0LL);
    t14 = (t15 + 56U);
    t20 = *((char **)t14);
    t18 = *((int64 *)t20);
    xsi_process_wait(t1, t18);

LAB29:    t14 = (t1 + 88U);
    t21 = *((char **)t14);
    t23 = (t21 + 2480U);
    *((unsigned int *)t23) = 1U;
    t24 = (t1 + 88U);
    t28 = *((char **)t24);
    t29 = (t28 + 0U);
    getcontext(t29);
    t30 = (t1 + 88U);
    t31 = *((char **)t30);
    t32 = (t31 + 2480U);
    t17 = *((unsigned int *)t32);
    if (t17 == 1)
        goto LAB30;

LAB31:    t33 = (t1 + 88U);
    t34 = *((char **)t33);
    t35 = (t34 + 2480U);
    *((unsigned int *)t35) = 3U;

LAB27:
LAB28:
LAB26:    t17 = (0 + t3);
    t14 = (t5 + 56U);
    t20 = *((char **)t14);
    t21 = (t20 + 56U);
    t23 = *((char **)t21);
    *((unsigned char *)t23) = (unsigned char)3;
    xsi_driver_first_trans_delta(t5, t17, 1, 0LL);

LAB18:    if (t39 == t40)
        goto LAB19;

LAB32:    t16 = (t39 + t36);
    t39 = t16;
    goto LAB16;

LAB24:    xsi_saveStackAndSuspend(t1);
    goto LAB25;

LAB30:    xsi_saveStackAndSuspend(t1);
    goto LAB31;

LAB37:    xsi_saveStackAndSuspend(t1);
    goto LAB38;

LAB43:    xsi_saveStackAndSuspend(t1);
    goto LAB44;

LAB49:    xsi_saveStackAndSuspend(t1);
    goto LAB50;

LAB55:    xsi_saveStackAndSuspend(t1);
    goto LAB56;

}

static void work_a_4037138396_2372691052_p_5(char *t0)
{
    char *t1;
    char *t2;
    int64 t3;

LAB0:    t1 = (t0 + 9312U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(245, ng0);
    t3 = (1 * 1000000LL);
    t2 = (t0 + 9120);
    xsi_process_wait(t2, t3);

LAB6:    *((char **)t1) = &&LAB7;

LAB1:    return;
LAB4:    xsi_set_current_line(257, ng0);

LAB10:    *((char **)t1) = &&LAB11;
    goto LAB1;

LAB5:    goto LAB4;

LAB7:    goto LAB5;

LAB8:    goto LAB2;

LAB9:    goto LAB8;

LAB11:    goto LAB9;

}


extern void work_a_4037138396_2372691052_init()
{
	static char *pe[] = {(void *)work_a_4037138396_2372691052_p_0,(void *)work_a_4037138396_2372691052_p_1,(void *)work_a_4037138396_2372691052_p_2,(void *)work_a_4037138396_2372691052_p_3,(void *)work_a_4037138396_2372691052_p_4,(void *)work_a_4037138396_2372691052_p_5};
	static char *se[] = {(void *)work_a_4037138396_2372691052_sub_3023655556_2855802964,(void *)work_a_4037138396_2372691052_sub_3715734401_2855802964};
	xsi_register_didat("work_a_4037138396_2372691052", "isim/TestbenchBoard_isim_beh.exe.sim/work/a_4037138396_2372691052.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}
