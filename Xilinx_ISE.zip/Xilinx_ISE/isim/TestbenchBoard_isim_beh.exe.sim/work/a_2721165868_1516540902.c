/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "E:/N.I.G.E.-Machine/VHDL/SPImaster3.vhd";
extern char *IEEE_P_2592010699;
extern char *IEEE_P_3620187407;

unsigned char ieee_p_2592010699_sub_1605435078_503743352(char *, unsigned char , unsigned char );
unsigned char ieee_p_2592010699_sub_1690584930_503743352(char *, unsigned char );
unsigned char ieee_p_2592010699_sub_1744673427_503743352(char *, char *, unsigned int , unsigned int );
char *ieee_p_3620187407_sub_436279890_3965413181(char *, char *, char *, char *, int );


static void work_a_2721165868_1516540902_p_0(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    unsigned char t4;
    char *t5;
    char *t6;
    int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned char t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    static char *nl0[] = {&&LAB6, &&LAB6, &&LAB6, &&LAB5, &&LAB6, &&LAB6, &&LAB6, &&LAB6, &&LAB6};

LAB0:    t1 = (t0 + 5712U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(37, ng0);
    t2 = (t0 + 4392U);
    t3 = *((char **)t2);
    t4 = *((unsigned char *)t3);
    t2 = (char *)((nl0) + t4);
    goto **((char **)t2);

LAB4:    xsi_set_current_line(37, ng0);

LAB9:    t2 = (t0 + 8264);
    *((int *)t2) = 1;
    *((char **)t1) = &&LAB10;

LAB1:    return;
LAB5:    xsi_set_current_line(38, ng0);
    t5 = (t0 + 3592U);
    t6 = *((char **)t5);
    t7 = (8 - 8);
    t8 = (t7 * -1);
    t9 = (1U * t8);
    t10 = (0 + t9);
    t5 = (t6 + t10);
    t11 = *((unsigned char *)t5);
    t12 = (t0 + 8488);
    t13 = (t12 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    *((unsigned char *)t16) = t11;
    xsi_driver_first_trans_fast_port(t12);
    goto LAB4;

LAB6:    xsi_set_current_line(38, ng0);
    t2 = (t0 + 2792U);
    t3 = *((char **)t2);
    t4 = *((unsigned char *)t3);
    t2 = (t0 + 8488);
    t5 = (t2 + 56U);
    t6 = *((char **)t5);
    t12 = (t6 + 56U);
    t13 = *((char **)t12);
    *((unsigned char *)t13) = t4;
    xsi_driver_first_trans_fast_port(t2);
    goto LAB4;

LAB7:    t3 = (t0 + 8264);
    *((int *)t3) = 0;
    goto LAB2;

LAB8:    goto LAB7;

LAB10:    goto LAB8;

}

static void work_a_2721165868_1516540902_p_1(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    int t4;
    unsigned int t5;
    unsigned int t6;
    unsigned int t7;
    unsigned char t8;
    char *t9;
    char *t10;
    char *t11;
    unsigned char t12;
    char *t13;
    unsigned char t14;
    unsigned char t15;
    char *t16;
    char *t17;
    char *t18;
    char *t19;
    static char *nl0[] = {&&LAB6, &&LAB6, &&LAB5, &&LAB6, &&LAB6, &&LAB6, &&LAB6, &&LAB6, &&LAB6};

LAB0:    t1 = (t0 + 5960U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(41, ng0);
    t2 = (t0 + 2632U);
    t3 = *((char **)t2);
    t4 = (1 - 1);
    t5 = (t4 * -1);
    t6 = (1U * t5);
    t7 = (0 + t6);
    t2 = (t3 + t7);
    t8 = *((unsigned char *)t2);
    t9 = (char *)((nl0) + t8);
    goto **((char **)t9);

LAB4:    xsi_set_current_line(41, ng0);

LAB9:    t2 = (t0 + 8280);
    *((int *)t2) = 1;
    *((char **)t1) = &&LAB10;

LAB1:    return;
LAB5:    xsi_set_current_line(42, ng0);
    t10 = (t0 + 4392U);
    t11 = *((char **)t10);
    t12 = *((unsigned char *)t11);
    t10 = (t0 + 1192U);
    t13 = *((char **)t10);
    t14 = *((unsigned char *)t13);
    t15 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t12, t14);
    t10 = (t0 + 8552);
    t16 = (t10 + 56U);
    t17 = *((char **)t16);
    t18 = (t17 + 56U);
    t19 = *((char **)t18);
    *((unsigned char *)t19) = t15;
    xsi_driver_first_trans_fast_port(t10);
    goto LAB4;

LAB6:    xsi_set_current_line(42, ng0);
    t2 = (t0 + 4392U);
    t3 = *((char **)t2);
    t8 = *((unsigned char *)t3);
    t2 = (t0 + 1192U);
    t9 = *((char **)t2);
    t12 = *((unsigned char *)t9);
    t14 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t8, t12);
    t15 = ieee_p_2592010699_sub_1690584930_503743352(IEEE_P_2592010699, t14);
    t2 = (t0 + 8552);
    t10 = (t2 + 56U);
    t11 = *((char **)t10);
    t13 = (t11 + 56U);
    t16 = *((char **)t13);
    *((unsigned char *)t16) = t15;
    xsi_driver_first_trans_fast_port(t2);
    goto LAB4;

LAB7:    t3 = (t0 + 8280);
    *((int *)t3) = 0;
    goto LAB2;

LAB8:    goto LAB7;

LAB10:    goto LAB8;

}

static void work_a_2721165868_1516540902_p_2(char *t0)
{
    char t3[16];
    char *t1;
    char *t2;
    char *t4;
    char *t5;
    unsigned int t6;
    unsigned char t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;

LAB0:    xsi_set_current_line(45, ng0);

LAB3:    t1 = (t0 + 1992U);
    t2 = *((char **)t1);
    t4 = ((IEEE_P_2592010699) + 4024);
    t5 = (t0 + 12708U);
    t1 = xsi_base_array_concat(t1, t3, t4, (char)97, t2, t5, (char)99, (unsigned char)2, (char)101);
    t6 = (8U + 1U);
    t7 = (9U != t6);
    if (t7 == 1)
        goto LAB5;

LAB6:    t8 = (t0 + 8616);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    memcpy(t12, t1, 9U);
    xsi_driver_first_trans_fast(t8);

LAB2:    t13 = (t0 + 8296);
    *((int *)t13) = 1;

LAB1:    return;
LAB4:    goto LAB2;

LAB5:    xsi_size_not_matching(9U, t6, 0);
    goto LAB6;

}

static void work_a_2721165868_1516540902_p_3(char *t0)
{
    char t7[16];
    char t9[16];
    char *t1;
    char *t2;
    unsigned int t3;
    unsigned int t4;
    unsigned int t5;
    char *t6;
    char *t8;
    char *t10;
    char *t11;
    int t12;
    unsigned int t13;
    unsigned char t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;
    char *t19;

LAB0:    xsi_set_current_line(46, ng0);

LAB3:    t1 = (t0 + 3592U);
    t2 = *((char **)t1);
    t3 = (8 - 7);
    t4 = (t3 * 1U);
    t5 = (0 + t4);
    t1 = (t2 + t5);
    t8 = ((IEEE_P_2592010699) + 4024);
    t10 = (t9 + 0U);
    t11 = (t10 + 0U);
    *((int *)t11) = 7;
    t11 = (t10 + 4U);
    *((int *)t11) = 0;
    t11 = (t10 + 8U);
    *((int *)t11) = -1;
    t12 = (0 - 7);
    t13 = (t12 * -1);
    t13 = (t13 + 1);
    t11 = (t10 + 12U);
    *((unsigned int *)t11) = t13;
    t6 = xsi_base_array_concat(t6, t7, t8, (char)97, t1, t9, (char)99, (unsigned char)2, (char)101);
    t13 = (8U + 1U);
    t14 = (9U != t13);
    if (t14 == 1)
        goto LAB5;

LAB6:    t11 = (t0 + 8680);
    t15 = (t11 + 56U);
    t16 = *((char **)t15);
    t17 = (t16 + 56U);
    t18 = *((char **)t17);
    memcpy(t18, t6, 9U);
    xsi_driver_first_trans_fast(t11);

LAB2:    t19 = (t0 + 8312);
    *((int *)t19) = 1;

LAB1:    return;
LAB4:    goto LAB2;

LAB5:    xsi_size_not_matching(9U, t13, 0);
    goto LAB6;

}

static void work_a_2721165868_1516540902_p_4(char *t0)
{
    char t9[16];
    char t11[16];
    char *t1;
    char *t2;
    unsigned int t3;
    unsigned int t4;
    unsigned int t5;
    char *t6;
    char *t7;
    unsigned char t8;
    char *t10;
    char *t12;
    char *t13;
    int t14;
    unsigned int t15;
    unsigned char t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;

LAB0:    xsi_set_current_line(47, ng0);

LAB3:    t1 = (t0 + 3592U);
    t2 = *((char **)t1);
    t3 = (8 - 8);
    t4 = (t3 * 1U);
    t5 = (0 + t4);
    t1 = (t2 + t5);
    t6 = (t0 + 2312U);
    t7 = *((char **)t6);
    t8 = *((unsigned char *)t7);
    t10 = ((IEEE_P_2592010699) + 4024);
    t12 = (t11 + 0U);
    t13 = (t12 + 0U);
    *((int *)t13) = 8;
    t13 = (t12 + 4U);
    *((int *)t13) = 1;
    t13 = (t12 + 8U);
    *((int *)t13) = -1;
    t14 = (1 - 8);
    t15 = (t14 * -1);
    t15 = (t15 + 1);
    t13 = (t12 + 12U);
    *((unsigned int *)t13) = t15;
    t6 = xsi_base_array_concat(t6, t9, t10, (char)97, t1, t11, (char)99, t8, (char)101);
    t15 = (8U + 1U);
    t16 = (9U != t15);
    if (t16 == 1)
        goto LAB5;

LAB6:    t13 = (t0 + 8744);
    t17 = (t13 + 56U);
    t18 = *((char **)t17);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    memcpy(t20, t6, 9U);
    xsi_driver_first_trans_fast(t13);

LAB2:    t21 = (t0 + 8328);
    *((int *)t21) = 1;

LAB1:    return;
LAB4:    goto LAB2;

LAB5:    xsi_size_not_matching(9U, t15, 0);
    goto LAB6;

}

static void work_a_2721165868_1516540902_p_5(char *t0)
{
    char *t1;
    char *t2;
    unsigned int t3;
    unsigned int t4;
    unsigned int t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;

LAB0:    xsi_set_current_line(48, ng0);

LAB3:    t1 = (t0 + 3592U);
    t2 = *((char **)t1);
    t3 = (8 - 8);
    t4 = (t3 * 1U);
    t5 = (0 + t4);
    t1 = (t2 + t5);
    t6 = (t0 + 8808);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 8U);
    xsi_driver_first_trans_fast_port(t6);

LAB2:    t11 = (t0 + 8344);
    *((int *)t11) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_2721165868_1516540902_p_6(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    unsigned char t4;
    char *t5;
    unsigned char t6;
    char *t7;
    char *t8;
    char *t9;

LAB0:    t1 = (t0 + 7200U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(52, ng0);

LAB6:    t2 = (t0 + 8360);
    *((int *)t2) = 1;
    *((char **)t1) = &&LAB7;

LAB1:    return;
LAB4:    t5 = (t0 + 8360);
    *((int *)t5) = 0;
    xsi_set_current_line(53, ng0);
    t2 = (t0 + 1352U);
    t3 = *((char **)t2);
    t4 = *((unsigned char *)t3);
    t6 = (t4 == (unsigned char)3);
    if (t6 != 0)
        goto LAB8;

LAB10:    xsi_set_current_line(57, ng0);
    t2 = (t0 + 3432U);
    t3 = *((char **)t2);
    t4 = *((unsigned char *)t3);
    t2 = (t0 + 8872);
    t5 = (t2 + 56U);
    t7 = *((char **)t5);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    *((unsigned char *)t9) = t4;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(58, ng0);
    t2 = (t0 + 1192U);
    t3 = *((char **)t2);
    t4 = *((unsigned char *)t3);
    t2 = (t0 + 8936);
    t5 = (t2 + 56U);
    t7 = *((char **)t5);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    *((unsigned char *)t9) = t4;
    xsi_driver_first_trans_fast(t2);

LAB9:    goto LAB2;

LAB5:    t3 = (t0 + 992U);
    t4 = ieee_p_2592010699_sub_1744673427_503743352(IEEE_P_2592010699, t3, 0U, 0U);
    if (t4 == 1)
        goto LAB4;
    else
        goto LAB6;

LAB7:    goto LAB5;

LAB8:    xsi_set_current_line(54, ng0);
    t2 = (t0 + 8872);
    t5 = (t2 + 56U);
    t7 = *((char **)t5);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    *((unsigned char *)t9) = (unsigned char)0;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(55, ng0);
    t2 = (t0 + 8936);
    t3 = (t2 + 56U);
    t5 = *((char **)t3);
    t7 = (t5 + 56U);
    t8 = *((char **)t7);
    *((unsigned char *)t8) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    goto LAB9;

}

static void work_a_2721165868_1516540902_p_7(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    unsigned char t4;
    char *t5;
    char *t6;
    unsigned char t7;
    unsigned char t8;
    char *t9;
    unsigned char t10;
    unsigned char t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    unsigned char t16;
    int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned char t21;
    unsigned char t22;
    unsigned char t23;
    unsigned char t24;
    unsigned char t25;
    unsigned char t26;
    unsigned char t27;
    unsigned char t28;
    int t29;
    unsigned int t30;
    unsigned int t31;
    unsigned int t32;
    unsigned char t33;
    unsigned char t34;
    char *t35;
    char *t36;
    char *t37;
    char *t38;
    static char *nl0[] = {&&LAB3, &&LAB4, &&LAB5};

LAB0:    xsi_set_current_line(64, ng0);
    t1 = (t0 + 3272U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (char *)((nl0) + t3);
    goto **((char **)t1);

LAB2:    t1 = (t0 + 8376);
    *((int *)t1) = 1;

LAB1:    return;
LAB3:    xsi_set_current_line(66, ng0);
    t5 = (t0 + 1672U);
    t6 = *((char **)t5);
    t7 = *((unsigned char *)t6);
    t8 = (t7 == (unsigned char)3);
    if (t8 == 1)
        goto LAB9;

LAB10:    t4 = (unsigned char)0;

LAB11:    if (t4 != 0)
        goto LAB6;

LAB8:    xsi_set_current_line(69, ng0);
    t1 = (t0 + 9000);
    t2 = (t1 + 56U);
    t5 = *((char **)t2);
    t6 = (t5 + 56U);
    t9 = *((char **)t6);
    *((unsigned char *)t9) = (unsigned char)0;
    xsi_driver_first_trans_fast(t1);

LAB7:    xsi_set_current_line(71, ng0);
    t1 = (t0 + 9064);
    t2 = (t1 + 56U);
    t5 = *((char **)t2);
    t6 = (t5 + 56U);
    t9 = *((char **)t6);
    *((unsigned char *)t9) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t1);
    goto LAB2;

LAB4:    xsi_set_current_line(74, ng0);
    t1 = (t0 + 1192U);
    t2 = *((char **)t1);
    t8 = *((unsigned char *)t2);
    t10 = (t8 == (unsigned char)2);
    if (t10 == 1)
        goto LAB21;

LAB22:    t7 = (unsigned char)0;

LAB23:    if (t7 == 1)
        goto LAB18;

LAB19:    t4 = (unsigned char)0;

LAB20:    if (t4 == 1)
        goto LAB15;

LAB16:    t9 = (t0 + 1192U);
    t12 = *((char **)t9);
    t25 = *((unsigned char *)t12);
    t26 = (t25 == (unsigned char)3);
    if (t26 == 1)
        goto LAB27;

LAB28:    t24 = (unsigned char)0;

LAB29:    if (t24 == 1)
        goto LAB24;

LAB25:    t23 = (unsigned char)0;

LAB26:    t3 = t23;

LAB17:    if (t3 != 0)
        goto LAB12;

LAB14:    xsi_set_current_line(78, ng0);
    t1 = (t0 + 9000);
    t2 = (t1 + 56U);
    t5 = *((char **)t2);
    t6 = (t5 + 56U);
    t9 = *((char **)t6);
    *((unsigned char *)t9) = (unsigned char)1;
    xsi_driver_first_trans_fast(t1);

LAB13:    xsi_set_current_line(80, ng0);
    t1 = (t0 + 9064);
    t2 = (t1 + 56U);
    t5 = *((char **)t2);
    t6 = (t5 + 56U);
    t9 = *((char **)t6);
    *((unsigned char *)t9) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    goto LAB2;

LAB5:    xsi_set_current_line(83, ng0);
    t1 = (t0 + 2952U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t4 = (t3 == (unsigned char)0);
    if (t4 != 0)
        goto LAB30;

LAB32:    xsi_set_current_line(86, ng0);
    t1 = (t0 + 9000);
    t2 = (t1 + 56U);
    t5 = *((char **)t2);
    t6 = (t5 + 56U);
    t9 = *((char **)t6);
    *((unsigned char *)t9) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);

LAB31:    xsi_set_current_line(88, ng0);
    t1 = (t0 + 9064);
    t2 = (t1 + 56U);
    t5 = *((char **)t2);
    t6 = (t5 + 56U);
    t9 = *((char **)t6);
    *((unsigned char *)t9) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    goto LAB2;

LAB6:    xsi_set_current_line(67, ng0);
    t5 = (t0 + 9000);
    t12 = (t5 + 56U);
    t13 = *((char **)t12);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    *((unsigned char *)t15) = (unsigned char)1;
    xsi_driver_first_trans_fast(t5);
    goto LAB7;

LAB9:    t5 = (t0 + 2952U);
    t9 = *((char **)t5);
    t10 = *((unsigned char *)t9);
    t11 = (t10 == (unsigned char)0);
    t4 = t11;
    goto LAB11;

LAB12:    xsi_set_current_line(76, ng0);
    t15 = (t0 + 9000);
    t35 = (t15 + 56U);
    t36 = *((char **)t35);
    t37 = (t36 + 56U);
    t38 = *((char **)t37);
    *((unsigned char *)t38) = (unsigned char)2;
    xsi_driver_first_trans_fast(t15);
    goto LAB13;

LAB15:    t3 = (unsigned char)1;
    goto LAB17;

LAB18:    t1 = (t0 + 2632U);
    t6 = *((char **)t1);
    t17 = (0 - 1);
    t18 = (t17 * -1);
    t19 = (1U * t18);
    t20 = (0 + t19);
    t1 = (t6 + t20);
    t21 = *((unsigned char *)t1);
    t22 = (t21 == (unsigned char)2);
    t4 = t22;
    goto LAB20;

LAB21:    t1 = (t0 + 4552U);
    t5 = *((char **)t1);
    t11 = *((unsigned char *)t5);
    t16 = (t11 == (unsigned char)3);
    t7 = t16;
    goto LAB23;

LAB24:    t9 = (t0 + 2632U);
    t14 = *((char **)t9);
    t29 = (0 - 1);
    t30 = (t29 * -1);
    t31 = (1U * t30);
    t32 = (0 + t31);
    t9 = (t14 + t32);
    t33 = *((unsigned char *)t9);
    t34 = (t33 == (unsigned char)3);
    t23 = t34;
    goto LAB26;

LAB27:    t9 = (t0 + 4552U);
    t13 = *((char **)t9);
    t27 = *((unsigned char *)t13);
    t28 = (t27 == (unsigned char)2);
    t24 = t28;
    goto LAB29;

LAB30:    xsi_set_current_line(84, ng0);
    t1 = (t0 + 9000);
    t5 = (t1 + 56U);
    t6 = *((char **)t5);
    t9 = (t6 + 56U);
    t12 = *((char **)t9);
    *((unsigned char *)t12) = (unsigned char)0;
    xsi_driver_first_trans_fast(t1);
    goto LAB31;

}

static void work_a_2721165868_1516540902_p_8(char *t0)
{
    char t44[16];
    char *t1;
    char *t2;
    char *t3;
    unsigned char t4;
    char *t5;
    unsigned char t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    unsigned char t12;
    unsigned char t13;
    unsigned char t14;
    unsigned char t15;
    unsigned char t16;
    int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned char t21;
    unsigned char t22;
    unsigned char t23;
    unsigned char t24;
    unsigned char t25;
    unsigned char t26;
    unsigned char t27;
    unsigned char t28;
    int t29;
    unsigned int t30;
    unsigned int t31;
    unsigned int t32;
    unsigned char t33;
    unsigned char t34;
    char *t35;
    char *t36;
    unsigned char t37;
    unsigned char t38;
    char *t39;
    char *t40;
    char *t41;
    char *t42;
    char *t43;

LAB0:    t1 = (t0 + 7696U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(95, ng0);

LAB6:    t2 = (t0 + 8392);
    *((int *)t2) = 1;
    *((char **)t1) = &&LAB7;

LAB1:    return;
LAB4:    t5 = (t0 + 8392);
    *((int *)t5) = 0;
    xsi_set_current_line(97, ng0);
    t2 = (t0 + 1352U);
    t3 = *((char **)t2);
    t4 = *((unsigned char *)t3);
    t6 = (t4 == (unsigned char)3);
    if (t6 != 0)
        goto LAB8;

LAB10:    t2 = (t0 + 1192U);
    t3 = *((char **)t2);
    t13 = *((unsigned char *)t3);
    t14 = (t13 == (unsigned char)3);
    if (t14 == 1)
        goto LAB19;

LAB20:    t12 = (unsigned char)0;

LAB21:    if (t12 == 1)
        goto LAB16;

LAB17:    t6 = (unsigned char)0;

LAB18:    if (t6 == 1)
        goto LAB13;

LAB14:    t8 = (t0 + 1192U);
    t9 = *((char **)t8);
    t25 = *((unsigned char *)t9);
    t26 = (t25 == (unsigned char)2);
    if (t26 == 1)
        goto LAB25;

LAB26:    t24 = (unsigned char)0;

LAB27:    if (t24 == 1)
        goto LAB22;

LAB23:    t23 = (unsigned char)0;

LAB24:    t4 = t23;

LAB15:    if (t4 != 0)
        goto LAB11;

LAB12:    t2 = (t0 + 1192U);
    t3 = *((char **)t2);
    t13 = *((unsigned char *)t3);
    t14 = (t13 == (unsigned char)2);
    if (t14 == 1)
        goto LAB39;

LAB40:    t12 = (unsigned char)0;

LAB41:    if (t12 == 1)
        goto LAB36;

LAB37:    t6 = (unsigned char)0;

LAB38:    if (t6 == 1)
        goto LAB33;

LAB34:    t8 = (t0 + 1192U);
    t9 = *((char **)t8);
    t25 = *((unsigned char *)t9);
    t26 = (t25 == (unsigned char)3);
    if (t26 == 1)
        goto LAB45;

LAB46:    t24 = (unsigned char)0;

LAB47:    if (t24 == 1)
        goto LAB42;

LAB43:    t23 = (unsigned char)0;

LAB44:    t4 = t23;

LAB35:    if (t4 != 0)
        goto LAB31;

LAB32:
LAB9:    goto LAB2;

LAB5:    t3 = (t0 + 992U);
    t4 = ieee_p_2592010699_sub_1744673427_503743352(IEEE_P_2592010699, t3, 0U, 0U);
    if (t4 == 1)
        goto LAB4;
    else
        goto LAB6;

LAB7:    goto LAB5;

LAB8:    xsi_set_current_line(98, ng0);
    t2 = xsi_get_transient_memory(3U);
    memset(t2, 0, 3U);
    t5 = t2;
    memset(t5, (unsigned char)2, 3U);
    t7 = (t0 + 9128);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    t10 = (t9 + 56U);
    t11 = *((char **)t10);
    memcpy(t11, t2, 3U);
    xsi_driver_first_trans_fast(t7);
    xsi_set_current_line(99, ng0);
    t2 = (t0 + 3912U);
    t3 = *((char **)t2);
    t2 = (t0 + 9192);
    t5 = (t2 + 56U);
    t7 = *((char **)t5);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t3, 9U);
    xsi_driver_first_trans_fast(t2);
    goto LAB9;

LAB11:    xsi_set_current_line(103, ng0);
    t35 = (t0 + 2952U);
    t36 = *((char **)t35);
    t37 = *((unsigned char *)t36);
    t38 = (t37 == (unsigned char)1);
    if (t38 != 0)
        goto LAB28;

LAB30:
LAB29:    goto LAB9;

LAB13:    t4 = (unsigned char)1;
    goto LAB15;

LAB16:    t2 = (t0 + 2632U);
    t7 = *((char **)t2);
    t17 = (0 - 1);
    t18 = (t17 * -1);
    t19 = (1U * t18);
    t20 = (0 + t19);
    t2 = (t7 + t20);
    t21 = *((unsigned char *)t2);
    t22 = (t21 == (unsigned char)2);
    t6 = t22;
    goto LAB18;

LAB19:    t2 = (t0 + 4552U);
    t5 = *((char **)t2);
    t15 = *((unsigned char *)t5);
    t16 = (t15 == (unsigned char)2);
    t12 = t16;
    goto LAB21;

LAB22:    t8 = (t0 + 2632U);
    t11 = *((char **)t8);
    t29 = (0 - 1);
    t30 = (t29 * -1);
    t31 = (1U * t30);
    t32 = (0 + t31);
    t8 = (t11 + t32);
    t33 = *((unsigned char *)t8);
    t34 = (t33 == (unsigned char)3);
    t23 = t34;
    goto LAB24;

LAB25:    t8 = (t0 + 4552U);
    t10 = *((char **)t8);
    t27 = *((unsigned char *)t10);
    t28 = (t27 == (unsigned char)3);
    t24 = t28;
    goto LAB27;

LAB28:    xsi_set_current_line(104, ng0);
    t35 = (t0 + 4232U);
    t39 = *((char **)t35);
    t35 = (t0 + 9192);
    t40 = (t35 + 56U);
    t41 = *((char **)t40);
    t42 = (t41 + 56U);
    t43 = *((char **)t42);
    memcpy(t43, t39, 9U);
    xsi_driver_first_trans_fast(t35);
    goto LAB29;

LAB31:    xsi_set_current_line(109, ng0);
    t35 = (t0 + 2952U);
    t36 = *((char **)t35);
    t37 = *((unsigned char *)t36);
    t38 = (t37 == (unsigned char)1);
    if (t38 != 0)
        goto LAB48;

LAB50:    t2 = (t0 + 3272U);
    t3 = *((char **)t2);
    t4 = *((unsigned char *)t3);
    t6 = (t4 == (unsigned char)1);
    if (t6 != 0)
        goto LAB53;

LAB54:
LAB49:    xsi_set_current_line(115, ng0);
    t2 = (t0 + 3112U);
    t3 = *((char **)t2);
    t4 = *((unsigned char *)t3);
    t2 = (t0 + 9256);
    t5 = (t2 + 56U);
    t7 = *((char **)t5);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    *((unsigned char *)t9) = t4;
    xsi_driver_first_trans_fast(t2);
    goto LAB9;

LAB33:    t4 = (unsigned char)1;
    goto LAB35;

LAB36:    t2 = (t0 + 2632U);
    t7 = *((char **)t2);
    t17 = (0 - 1);
    t18 = (t17 * -1);
    t19 = (1U * t18);
    t20 = (0 + t19);
    t2 = (t7 + t20);
    t21 = *((unsigned char *)t2);
    t22 = (t21 == (unsigned char)2);
    t6 = t22;
    goto LAB38;

LAB39:    t2 = (t0 + 4552U);
    t5 = *((char **)t2);
    t15 = *((unsigned char *)t5);
    t16 = (t15 == (unsigned char)3);
    t12 = t16;
    goto LAB41;

LAB42:    t8 = (t0 + 2632U);
    t11 = *((char **)t8);
    t29 = (0 - 1);
    t30 = (t29 * -1);
    t31 = (1U * t30);
    t32 = (0 + t31);
    t8 = (t11 + t32);
    t33 = *((unsigned char *)t8);
    t34 = (t33 == (unsigned char)3);
    t23 = t34;
    goto LAB44;

LAB45:    t8 = (t0 + 4552U);
    t10 = *((char **)t8);
    t27 = *((unsigned char *)t10);
    t28 = (t27 == (unsigned char)2);
    t24 = t28;
    goto LAB47;

LAB48:    xsi_set_current_line(110, ng0);
    t35 = (t0 + 4072U);
    t39 = *((char **)t35);
    t35 = (t0 + 9192);
    t40 = (t35 + 56U);
    t41 = *((char **)t40);
    t42 = (t41 + 56U);
    t43 = *((char **)t42);
    memcpy(t43, t39, 9U);
    xsi_driver_first_trans_fast(t35);
    xsi_set_current_line(111, ng0);
    t2 = (t0 + 3752U);
    t3 = *((char **)t2);
    t2 = (t0 + 12756U);
    t5 = ieee_p_3620187407_sub_436279890_3965413181(IEEE_P_3620187407, t44, t3, t2, 1);
    t7 = (t44 + 12U);
    t18 = *((unsigned int *)t7);
    t19 = (1U * t18);
    t4 = (3U != t19);
    if (t4 == 1)
        goto LAB51;

LAB52:    t8 = (t0 + 9128);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    t11 = (t10 + 56U);
    t35 = *((char **)t11);
    memcpy(t35, t5, 3U);
    xsi_driver_first_trans_fast(t8);
    goto LAB49;

LAB51:    xsi_size_not_matching(3U, t19, 0);
    goto LAB52;

LAB53:    xsi_set_current_line(113, ng0);
    t2 = (t0 + 3912U);
    t5 = *((char **)t2);
    t2 = (t0 + 9192);
    t7 = (t2 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t5, 9U);
    xsi_driver_first_trans_fast(t2);
    goto LAB49;

}

static void work_a_2721165868_1516540902_p_9(char *t0)
{
    char t12[16];
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    int t13;
    unsigned int t14;
    char *t15;
    char *t16;
    static char *nl0[] = {&&LAB3, &&LAB4};

LAB0:    xsi_set_current_line(122, ng0);
    t1 = (t0 + 2952U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (char *)((nl0) + t3);
    goto **((char **)t1);

LAB2:    t1 = (t0 + 8408);
    *((int *)t1) = 1;

LAB1:    return;
LAB3:    xsi_set_current_line(124, ng0);
    t4 = (t0 + 3272U);
    t5 = *((char **)t4);
    t6 = *((unsigned char *)t5);
    t7 = (t6 == (unsigned char)1);
    if (t7 != 0)
        goto LAB5;

LAB7:    xsi_set_current_line(127, ng0);
    t1 = (t0 + 9320);
    t2 = (t1 + 56U);
    t4 = *((char **)t2);
    t5 = (t4 + 56U);
    t8 = *((char **)t5);
    *((unsigned char *)t8) = (unsigned char)0;
    xsi_driver_first_trans_fast(t1);

LAB6:    xsi_set_current_line(129, ng0);
    t1 = (t0 + 9384);
    t2 = (t1 + 56U);
    t4 = *((char **)t2);
    t5 = (t4 + 56U);
    t8 = *((char **)t5);
    *((unsigned char *)t8) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    goto LAB2;

LAB4:    xsi_set_current_line(132, ng0);
    t1 = (t0 + 3752U);
    t2 = *((char **)t1);
    t1 = (t0 + 12756U);
    t4 = (t0 + 12857);
    t8 = (t12 + 0U);
    t9 = (t8 + 0U);
    *((int *)t9) = 0;
    t9 = (t8 + 4U);
    *((int *)t9) = 2;
    t9 = (t8 + 8U);
    *((int *)t9) = 1;
    t13 = (2 - 0);
    t14 = (t13 * 1);
    t14 = (t14 + 1);
    t9 = (t8 + 12U);
    *((unsigned int *)t9) = t14;
    t3 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t2, t1, t4, t12);
    if (t3 != 0)
        goto LAB8;

LAB10:    xsi_set_current_line(135, ng0);
    t1 = (t0 + 9320);
    t2 = (t1 + 56U);
    t4 = *((char **)t2);
    t5 = (t4 + 56U);
    t8 = *((char **)t5);
    *((unsigned char *)t8) = (unsigned char)1;
    xsi_driver_first_trans_fast(t1);

LAB9:    xsi_set_current_line(137, ng0);
    t1 = (t0 + 9384);
    t2 = (t1 + 56U);
    t4 = *((char **)t2);
    t5 = (t4 + 56U);
    t8 = *((char **)t5);
    *((unsigned char *)t8) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);
    goto LAB2;

LAB5:    xsi_set_current_line(125, ng0);
    t4 = (t0 + 9320);
    t8 = (t4 + 56U);
    t9 = *((char **)t8);
    t10 = (t9 + 56U);
    t11 = *((char **)t10);
    *((unsigned char *)t11) = (unsigned char)1;
    xsi_driver_first_trans_fast(t4);
    goto LAB6;

LAB8:    xsi_set_current_line(133, ng0);
    t9 = (t0 + 9320);
    t10 = (t9 + 56U);
    t11 = *((char **)t10);
    t15 = (t11 + 56U);
    t16 = *((char **)t15);
    *((unsigned char *)t16) = (unsigned char)0;
    xsi_driver_first_trans_fast(t9);
    goto LAB9;

}


extern void work_a_2721165868_1516540902_init()
{
	static char *pe[] = {(void *)work_a_2721165868_1516540902_p_0,(void *)work_a_2721165868_1516540902_p_1,(void *)work_a_2721165868_1516540902_p_2,(void *)work_a_2721165868_1516540902_p_3,(void *)work_a_2721165868_1516540902_p_4,(void *)work_a_2721165868_1516540902_p_5,(void *)work_a_2721165868_1516540902_p_6,(void *)work_a_2721165868_1516540902_p_7,(void *)work_a_2721165868_1516540902_p_8,(void *)work_a_2721165868_1516540902_p_9};
	xsi_register_didat("work_a_2721165868_1516540902", "isim/TestbenchBoard_isim_beh.exe.sim/work/a_2721165868_1516540902.didat");
	xsi_register_executes(pe);
}
