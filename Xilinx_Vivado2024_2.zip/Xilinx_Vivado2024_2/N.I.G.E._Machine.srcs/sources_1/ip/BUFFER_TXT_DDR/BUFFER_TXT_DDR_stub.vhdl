-- Copyright 1986-2015 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2015.4 (win64) Build 1412921 Wed Nov 18 09:43:45 MST 2015
-- Date        : Sat Feb 06 22:12:44 2016
-- Host        : PANDABEAR running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode synth_stub
--               E:/N.I.G.E.-Machine/Xilinx_Vivado/N.I.G.E._Machine.srcs/sources_1/ip/BUFFER_TXT_DDR/BUFFER_TXT_DDR_stub.vhdl
-- Design      : BUFFER_TXT_DDR
-- Purpose     : Stub declaration of top-level module interface
-- Device      : xc7a100tcsg324-3
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity BUFFER_TXT_DDR is
  Port ( 
    clka : in STD_LOGIC;
    wea : in STD_LOGIC_VECTOR ( 0 to 0 );
    addra : in STD_LOGIC_VECTOR ( 5 downto 0 );
    dina : in STD_LOGIC_VECTOR ( 127 downto 0 );
    clkb : in STD_LOGIC;
    addrb : in STD_LOGIC_VECTOR ( 8 downto 0 );
    doutb : out STD_LOGIC_VECTOR ( 15 downto 0 )
  );

end BUFFER_TXT_DDR;

architecture stub of BUFFER_TXT_DDR is
attribute syn_black_box : boolean;
attribute black_box_pad_pin : string;
attribute syn_black_box of stub : architecture is true;
attribute black_box_pad_pin of stub : architecture is "clka,wea[0:0],addra[5:0],dina[127:0],clkb,addrb[8:0],doutb[15:0]";
attribute x_core_info : string;
attribute x_core_info of stub : architecture is "blk_mem_gen_v8_3_1,Vivado 2015.4";
begin
end;
