// Copyright 1986-2015 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2015.4 (win64) Build 1412921 Wed Nov 18 09:43:45 MST 2015
// Date        : Sat Feb 06 22:12:44 2016
// Host        : PANDABEAR running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode synth_stub
//               E:/N.I.G.E.-Machine/Xilinx_Vivado/N.I.G.E._Machine.srcs/sources_1/ip/BUFFER_TXT_DDR/BUFFER_TXT_DDR_stub.v
// Design      : BUFFER_TXT_DDR
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7a100tcsg324-3
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* x_core_info = "blk_mem_gen_v8_3_1,Vivado 2015.4" *)
module BUFFER_TXT_DDR(clka, wea, addra, dina, clkb, addrb, doutb)
/* synthesis syn_black_box black_box_pad_pin="clka,wea[0:0],addra[5:0],dina[127:0],clkb,addrb[8:0],doutb[15:0]" */;
  input clka;
  input [0:0]wea;
  input [5:0]addra;
  input [127:0]dina;
  input clkb;
  input [8:0]addrb;
  output [15:0]doutb;
endmodule
