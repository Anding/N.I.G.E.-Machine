The following files were generated for 'unsignedComparitor' in directory
E:\N.I.G.E.-Machine\Xilinx\ipcore_dir\

XCO file generator:
   Generate an XCO file for compatibility with legacy flows.

   * unsignedComparitor.xco

Creates an implementation netlist:
   Creates an implementation netlist for the IP.

   * unsignedComparitor.ngc
   * unsignedComparitor.v
   * unsignedComparitor.veo
   * unsignedComparitor.vhd
   * unsignedComparitor.vho

Creates an HDL instantiation template:
   Creates an HDL instantiation template for the IP.

   * unsignedComparitor.veo
   * unsignedComparitor.vho

IP Symbol Generator:
   Generate an IP symbol based on the current project options'.

   * unsignedComparitor.asy

Generate ISE metadata:
   Create a metadata file for use when including this core in ISE designs

   * unsignedComparitor_xmdf.tcl

Generate ISE subproject:
   Create an ISE subproject for use when including this core in ISE designs

   * _xmsgs/pn_parser.xmsgs
   * unsignedComparitor.gise
   * unsignedComparitor.xise

Deliver Readme:
   Readme file for the IP.

   * unsignedComparitor_readme.txt

Generate FLIST file:
   Text file listing all of the output files produced when a customized core was
   generated in the CORE Generator.

   * unsignedComparitor_flist.txt

Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

